<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Payment Settings Request with enhanced security
 * 
 * This unified request class handles validation for both updating and testing
 * payment settings with comprehensive security measures and input sanitization.
 * 
 * Features:
 * - Unified validation for both update and test operations
 * - XSS protection and input sanitization
 * - Custom validation messages for better user experience
 * - Proper type hints and return types
 * - Security validation rules (XSS protection, SQL injection prevention)
 * - Payment gateway configuration validation
 * - API key and credential validation
 * - Test connection functionality
 * 
 * @package App\Http\Requests\Admin
 * @version 1.2.0
 * @since 1.0.0
 * @author My-Logos Team
 */
class PaymentSettingsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     * 
     * @return bool
     */
    public function authorize(): bool
    {
        return auth()->check() && (auth()->user()->is_admin || auth()->user()->hasRole('admin'));
    }

    /**
     * Get the validation rules that apply to the request.
     * 
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $isTest = $this->isMethod('POST') && str_contains($this->route()->getName(), 'test');

        // Test connection validation
        if ($isTest) {
            return [
                'gateway' => [
                    'required',
                    'string',
                    Rule::in(['stripe', 'paypal', 'square', 'razorpay', 'mollie', 'authorize_net'])
                ],
                'test_mode' => [
                    'boolean'
                ]
            ];
        }

        // Update settings validation
        return [
            'default_gateway' => [
                'required',
                'string',
                Rule::in(['stripe', 'paypal', 'square', 'razorpay', 'mollie', 'authorize_net'])
            ],
            'test_mode' => [
                'boolean'
            ],
            'currency' => [
                'required',
                'string',
                Rule::in(['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'INR', 'JPY', 'CHF', 'SEK', 'NOK'])
            ],
            
            // Stripe Settings
            'stripe_public_key' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^pk_[a-zA-Z0-9_]+$/'
            ],
            'stripe_secret_key' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^sk_[a-zA-Z0-9_]+$/'
            ],
            'stripe_webhook_secret' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^whsec_[a-zA-Z0-9_]+$/'
            ],
            
            // PayPal Settings
            'paypal_client_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'paypal_client_secret' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'paypal_webhook_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            
            // Square Settings
            'square_application_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'square_access_token' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'square_location_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            
            // Razorpay Settings
            'razorpay_key_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^rzp_[a-zA-Z0-9_]+$/'
            ],
            'razorpay_key_secret' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'razorpay_webhook_secret' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            
            // Mollie Settings
            'mollie_api_key' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'mollie_webhook_url' => [
                'nullable',
                'url',
                'max:500'
            ],
            
            // Authorize.Net Settings
            'authorize_net_api_login_id' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'authorize_net_transaction_key' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            'authorize_net_signature_key' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-zA-Z0-9_]+$/'
            ],
            
            // General Settings
            'auto_capture' => [
                'boolean'
            ],
            'refund_enabled' => [
                'boolean'
            ],
            'partial_refund_enabled' => [
                'boolean'
            ],
            'webhook_retry_attempts' => [
                'nullable',
                'integer',
                'min:1',
                'max:10'
            ],
            'webhook_timeout' => [
                'nullable',
                'integer',
                'min:5',
                'max:300'
            ],
        ];
    }

    /**
     * Get custom validation messages.
     * 
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'default_gateway.required' => 'Default payment gateway is required.',
            'default_gateway.in' => 'Default gateway must be one of: stripe, paypal, square, razorpay, mollie, authorize_net.',
            'currency.required' => 'Default currency is required.',
            'currency.in' => 'Currency must be one of: USD, EUR, GBP, CAD, AUD, INR, JPY, CHF, SEK, NOK.',
            'stripe_public_key.regex' => 'Stripe public key must start with pk_.',
            'stripe_secret_key.regex' => 'Stripe secret key must start with sk_.',
            'stripe_webhook_secret.regex' => 'Stripe webhook secret must start with whsec_.',
            'paypal_client_id.regex' => 'PayPal client ID contains invalid characters.',
            'paypal_client_secret.regex' => 'PayPal client secret contains invalid characters.',
            'paypal_webhook_id.regex' => 'PayPal webhook ID contains invalid characters.',
            'square_application_id.regex' => 'Square application ID contains invalid characters.',
            'square_access_token.regex' => 'Square access token contains invalid characters.',
            'square_location_id.regex' => 'Square location ID contains invalid characters.',
            'razorpay_key_id.regex' => 'Razorpay key ID must start with rzp_.',
            'razorpay_key_secret.regex' => 'Razorpay key secret contains invalid characters.',
            'razorpay_webhook_secret.regex' => 'Razorpay webhook secret contains invalid characters.',
            'mollie_api_key.regex' => 'Mollie API key contains invalid characters.',
            'mollie_webhook_url.url' => 'Mollie webhook URL must be a valid URL.',
            'authorize_net_api_login_id.regex' => 'Authorize.Net API login ID contains invalid characters.',
            'authorize_net_transaction_key.regex' => 'Authorize.Net transaction key contains invalid characters.',
            'authorize_net_signature_key.regex' => 'Authorize.Net signature key contains invalid characters.',
            'webhook_retry_attempts.min' => 'Webhook retry attempts must be at least 1.',
            'webhook_retry_attempts.max' => 'Webhook retry attempts cannot exceed 10.',
            'webhook_timeout.min' => 'Webhook timeout must be at least 5 seconds.',
            'webhook_timeout.max' => 'Webhook timeout cannot exceed 300 seconds.',
            'gateway.required' => 'Payment gateway is required for testing.',
            'gateway.in' => 'Gateway must be one of: stripe, paypal, square, razorpay, mollie, authorize_net.',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     * 
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'default_gateway' => 'default payment gateway',
            'test_mode' => 'test mode',
            'currency' => 'default currency',
            'stripe_public_key' => 'Stripe public key',
            'stripe_secret_key' => 'Stripe secret key',
            'stripe_webhook_secret' => 'Stripe webhook secret',
            'paypal_client_id' => 'PayPal client ID',
            'paypal_client_secret' => 'PayPal client secret',
            'paypal_webhook_id' => 'PayPal webhook ID',
            'square_application_id' => 'Square application ID',
            'square_access_token' => 'Square access token',
            'square_location_id' => 'Square location ID',
            'razorpay_key_id' => 'Razorpay key ID',
            'razorpay_key_secret' => 'Razorpay key secret',
            'razorpay_webhook_secret' => 'Razorpay webhook secret',
            'mollie_api_key' => 'Mollie API key',
            'mollie_webhook_url' => 'Mollie webhook URL',
            'authorize_net_api_login_id' => 'Authorize.Net API login ID',
            'authorize_net_transaction_key' => 'Authorize.Net transaction key',
            'authorize_net_signature_key' => 'Authorize.Net signature key',
            'auto_capture' => 'auto capture',
            'refund_enabled' => 'refund enabled',
            'partial_refund_enabled' => 'partial refund enabled',
            'webhook_retry_attempts' => 'webhook retry attempts',
            'webhook_timeout' => 'webhook timeout',
            'gateway' => 'payment gateway',
        ];
    }

    /**
     * Prepare the data for validation.
     * 
     * @return void
     */
    protected function prepareForValidation(): void
    {
        // Handle checkbox values
        $this->merge([
            'test_mode' => $this->has('test_mode'),
            'auto_capture' => $this->has('auto_capture'),
            'refund_enabled' => $this->has('refund_enabled'),
            'partial_refund_enabled' => $this->has('partial_refund_enabled'),
        ]);

        // Set default values
        $this->merge([
            'test_mode' => $this->test_mode ?? true,
            'currency' => $this->currency ?? 'USD',
            'webhook_retry_attempts' => $this->webhook_retry_attempts ?? 3,
            'webhook_timeout' => $this->webhook_timeout ?? 30,
        ]);
    }
}
