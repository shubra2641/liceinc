<?php

/**
 * Blade-Specific Envato Compliance Audit
 * 
 * This script focuses specifically on Blade file violations
 * according to Envato marketplace standards.
 * 
 * @package Audit
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class BladeSpecificAudit
{
    private $projectRoot;
    private $results = [];
    private $stats = [
        'total_blade_files' => 0,
        'inline_css_violations' => 0,
        'inline_js_violations' => 0,
        'push_directive_violations' => 0,
        'php_block_violations' => 0,
        'svg_icon_violations' => 0,
        'block_in_inline_violations' => 0,
        'hardcoded_text_violations' => 0
    ];

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run Blade-specific audit
     */
    public function runAudit()
    {
        echo "🔧 Blade-Specific Envato Compliance Audit\n";
        echo "==========================================\n\n";

        $this->checkBladeFiles();
        $this->generateBladeReport();
    }

    /**
     * Check Blade files for violations
     */
    private function checkBladeFiles()
    {
        echo "📁 Checking Blade Files...\n";
        
        $bladeFiles = $this->getBladeFiles();
        
        foreach ($bladeFiles as $file) {
            $this->stats['total_blade_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for inline CSS
            $this->checkInlineCss($content, $relativePath);
            
            // Check for inline JavaScript
            $this->checkInlineJs($content, $relativePath);
            
            // Check for @push directives
            $this->checkPushDirectives($content, $relativePath);
            
            // Check for @php blocks
            $this->checkPhpBlocks($content, $relativePath);
            
            // Check for SVG icons
            $this->checkSvgIcons($content, $relativePath);
            
            // Check for block elements in inline elements
            $this->checkBlockInInline($content, $relativePath);
            
            // Check for hardcoded text
            $this->checkHardcodedText($content, $relativePath);
        }
    }

    /**
     * Check for inline CSS
     */
    private function checkInlineCss($content, $file)
    {
        if (preg_match_all('/style\s*=\s*["\']([^"\']*)["\']/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, 'Inline CSS found: ' . substr($match[0], 0, 50) . '...', 'INLINE_CSS');
                $this->stats['inline_css_violations']++;
            }
        }
    }

    /**
     * Check for inline JavaScript
     */
    private function checkInlineJs($content, $file)
    {
        if (preg_match_all('/<script[^>]*>([\s\S]*?)<\/script>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, 'Inline JavaScript found: ' . substr($match[0], 0, 50) . '...', 'INLINE_JS');
                $this->stats['inline_js_violations']++;
            }
        }
    }

    /**
     * Check for @push directives
     */
    private function checkPushDirectives($content, $file)
    {
        if (preg_match_all('/@push\s*\([\'"](styles|scripts)[\'"][\s\S]*?@endpush/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, '@push directive found: ' . substr($match[0], 0, 50) . '...', 'PUSH_DIRECTIVE');
                $this->stats['push_directive_violations']++;
            }
        }
    }

    /**
     * Check for @php blocks
     */
    private function checkPhpBlocks($content, $file)
    {
        if (preg_match_all('/@php[\s\S]*?@endphp/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, '@php block found: ' . substr($match[0], 0, 50) . '...', 'PHP_BLOCK');
                $this->stats['php_block_violations']++;
            }
        }
    }

    /**
     * Check for SVG icons
     */
    private function checkSvgIcons($content, $file)
    {
        if (preg_match_all('/<svg[\s\S]*?<\/svg>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, 'SVG icon found - use FontAwesome: ' . substr($match[0], 0, 50) . '...', 'SVG_ICON');
                $this->stats['svg_icon_violations']++;
            }
        }
    }

    /**
     * Check for block elements in inline elements
     */
    private function checkBlockInInline($content, $file)
    {
        if (preg_match_all('/<(span|em|strong|a)[^>]*>[\s\S]*?<(div|h[1-6]|p|section|article|header|footer|nav|main|aside)[^>]*>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $index => $match) {
                $this->addResult($file, 'Block element inside inline element: ' . substr($match[0], 0, 50) . '...', 'BLOCK_IN_INLINE');
                $this->stats['block_in_inline_violations']++;
            }
        }
    }

    /**
     * Check for hardcoded text
     */
    private function checkHardcodedText($content, $file)
    {
        // Look for text that's not using language system
        if (preg_match_all('/>([A-Za-z][^<]*?)</', $content, $matches, PREG_OFFSET_CAPTURE)) {
            foreach ($matches[1] as $index => $text) {
                if (is_array($text)) {
                    $text = $text[0];
                }
                $text = trim($text);
                if (strlen($text) > 3 && !preg_match('/@lang|__\(|{{/', $text) && !preg_match('/^\s*$/', $text)) {
                    $this->addResult($file, 'Hardcoded text found: ' . substr($text, 0, 30) . '...', 'HARDCODED_TEXT');
                    $this->stats['hardcoded_text_violations']++;
                    break; // Only report once per file
                }
            }
        }
    }

    /**
     * Get Blade files
     */
    private function getBladeFiles()
    {
        $files = [];
        $viewsPath = $this->projectRoot . '/resources/views';
        
        if (!is_dir($viewsPath)) {
            return $files;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($viewsPath, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php' && strpos($file->getFilename(), '.blade.php') !== false) {
                $files[] = $file->getPathname();
            }
        }
        
        return $files;
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'storage', 'node_modules', 'bootstrap/cache'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($this->projectRoot . '/', '', $filePath);
                
                // Skip files in excluded directories
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . '/') === 0 || $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if ($shouldExclude) {
                    continue;
                }
                
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $filePath;
                }
            }
        }
        
        return $files;
    }

    /**
     * Add result
     */
    private function addResult($file, $message, $type)
    {
        $this->results[] = [
            'file' => $file,
            'message' => $message,
            'type' => $type
        ];
    }

    /**
     * Generate Blade report
     */
    private function generateBladeReport()
    {
        echo "\n" . str_repeat("=", 70) . "\n";
        echo "📊 BLADE-SPECIFIC ENVATO COMPLIANCE AUDIT REPORT\n";
        echo str_repeat("=", 70) . "\n\n";
        
        echo "📈 SUMMARY:\n";
        echo "Total Blade Files Scanned: {$this->stats['total_blade_files']}\n";
        echo "Inline CSS Violations: {$this->stats['inline_css_violations']}\n";
        echo "Inline JavaScript Violations: {$this->stats['inline_js_violations']}\n";
        echo "@push Directive Violations: {$this->stats['push_directive_violations']}\n";
        echo "@php Block Violations: {$this->stats['php_block_violations']}\n";
        echo "SVG Icon Violations: {$this->stats['svg_icon_violations']}\n";
        echo "Block in Inline Violations: {$this->stats['block_in_inline_violations']}\n";
        echo "Hardcoded Text Violations: {$this->stats['hardcoded_text_violations']}\n\n";
        
        $totalViolations = $this->stats['inline_css_violations'] + $this->stats['inline_js_violations'] + 
                          $this->stats['push_directive_violations'] + $this->stats['php_block_violations'] + 
                          $this->stats['svg_icon_violations'] + $this->stats['block_in_inline_violations'] + 
                          $this->stats['hardcoded_text_violations'];
        
        echo "🎯 BLADE COMPLIANCE SCORE:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($totalViolations == 0) {
            echo "🟢 PERFECT BLADE COMPLIANCE (100/100)\n";
            echo "✅ All Blade files meet Envato standards!\n";
        } elseif ($totalViolations <= 5) {
            echo "🟡 GOOD BLADE COMPLIANCE (80-99/100)\n";
            echo "⚠️  Minor Blade issues need attention\n";
        } elseif ($totalViolations <= 15) {
            echo "🟠 FAIR BLADE COMPLIANCE (60-79/100)\n";
            echo "⚠️  Several Blade issues need fixing\n";
        } else {
            echo "🔴 POOR BLADE COMPLIANCE (0-59/100)\n";
            echo "❌ Major Blade issues need immediate attention\n";
        }
        
        echo "\n🔍 DETAILED VIOLATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        $violationTypes = array_count_values(array_column($this->results, 'type'));
        foreach ($violationTypes as $type => $count) {
            echo "• $type: $count violations\n";
        }
        
        echo "\n📋 TOP VIOLATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        $topViolations = array_slice($this->results, 0, 15);
        foreach ($topViolations as $result) {
            echo "❌ {$result['file']}: {$result['message']}\n";
        }
        
        echo "\n🎯 BLADE-SPECIFIC RECOMMENDATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($this->stats['inline_css_violations'] > 0) {
            echo "• Move all inline CSS to external files in public/assets/css/\n";
            echo "• Remove all style=\"\" attributes from Blade files\n";
        }
        
        if ($this->stats['inline_js_violations'] > 0) {
            echo "• Move all inline JavaScript to external files in public/assets/js/\n";
            echo "• Remove all <script> tags from Blade files\n";
        }
        
        if ($this->stats['push_directive_violations'] > 0) {
            echo "• Remove all @push('styles') and @push('scripts') directives\n";
            echo "• Import CSS/JS files directly in layout files\n";
        }
        
        if ($this->stats['php_block_violations'] > 0) {
            echo "• Remove all @php and @endphp blocks\n";
            echo "• Move PHP logic to controllers or services\n";
        }
        
        if ($this->stats['svg_icon_violations'] > 0) {
            echo "• Replace all SVG icons with FontAwesome classes\n";
            echo "• Use <i class=\"fas fa-icon\"></i> instead of <svg>\n";
        }
        
        if ($this->stats['block_in_inline_violations'] > 0) {
            echo "• Fix HTML structure - no block elements inside inline elements\n";
            echo "• Use proper semantic HTML structure\n";
        }
        
        if ($this->stats['hardcoded_text_violations'] > 0) {
            echo "• Use Laravel's language system for all text\n";
            echo "• Replace hardcoded text with @lang('key') or __('key')\n";
        }
        
        echo "\n✅ Blade-specific audit completed!\n";
    }
}

// Run the Blade-specific audit
$audit = new BladeSpecificAudit();
$audit->runAudit();
