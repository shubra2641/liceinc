<?php

/**
 * Comprehensive Envato Compliance Audit Script
 * 
 * This script performs comprehensive analysis based on official Envato
 * marketplace requirements and rejection criteria.
 * 
 * @package Audit
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class EnvatoComprehensiveAudit
{
    private $projectRoot;
    private $results = [];
    private $stats = [
        'total_files' => 0,
        'css_violations' => 0,
        'js_violations' => 0,
        'php_violations' => 0,
        'blade_violations' => 0,
        'security_issues' => 0,
        'quality_issues' => 0
    ];

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run comprehensive audit
     */
    public function runAudit()
    {
        echo "🔍 Comprehensive Envato Compliance Audit\n";
        echo "==========================================\n\n";

        $this->checkCssCompliance();
        $this->checkJavaScriptCompliance();
        $this->checkPhpCompliance();
        $this->checkBladeCompliance();
        $this->checkSecurityCompliance();
        $this->checkQualityCompliance();

        $this->generateComprehensiveReport();
    }

    /**
     * Check CSS compliance according to Envato standards
     */
    private function checkCssCompliance()
    {
        echo "🎨 Checking CSS Compliance...\n";
        
        $cssFiles = $this->getFilesByExtension(['.css', '.scss'], 'public/assets');
        
        foreach ($cssFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for low quality CSS (too simple)
            $this->checkCssQuality($content, $relativePath);
            
            // Check for duplicate CSS rules
            $this->checkDuplicateCssRules($content, $relativePath);
            
            // Check for CSS validation issues
            $this->checkCssValidation($content, $relativePath);
        }
    }

    /**
     * Check JavaScript compliance according to Envato standards
     */
    private function checkJavaScriptCompliance()
    {
        echo "📜 Checking JavaScript Compliance...\n";
        
        $jsFiles = $this->getFilesByExtension(['.js'], 'public/assets');
        
        foreach ($jsFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for progressive enhancement
            $this->checkProgressiveEnhancement($content, $relativePath);
            
            // Check for complexity and features
            $this->checkJsComplexity($content, $relativePath);
            
            // Check for implementation quality
            $this->checkJsImplementation($content, $relativePath);
        }
    }

    /**
     * Check PHP compliance according to Envato standards
     */
    private function checkPhpCompliance()
    {
        echo "🐘 Checking PHP Compliance...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php'], 'app');
        
        foreach ($phpFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check PSR-12 compliance
            $this->checkPsr12Compliance($content, $relativePath);
            
            // Check for Log::info in success operations
            $this->checkLoggingCompliance($content, $relativePath);
            
            // Check for feature complexity
            $this->checkFeatureComplexity($content, $relativePath);
            
            // Check for documentation quality
            $this->checkDocumentationQuality($content, $relativePath);
            
            // Check for integration ease
            $this->checkIntegrationEase($content, $relativePath);
        }
    }

    /**
     * Check Blade compliance according to Envato standards
     */
    private function checkBladeCompliance()
    {
        echo "🔧 Checking Blade Compliance...\n";
        
        $bladeFiles = $this->getFilesByExtension(['.blade.php'], 'resources/views');
        
        foreach ($bladeFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for inline CSS
            $this->checkInlineCss($content, $relativePath);
            
            // Check for inline JavaScript
            $this->checkInlineJs($content, $relativePath);
            
            // Check for @push directives
            $this->checkPushDirectives($content, $relativePath);
            
            // Check for SVG/path icons
            $this->checkSvgIcons($content, $relativePath);
            
            // Check for block elements in inline elements
            $this->checkBlockInInline($content, $relativePath);
        }
    }

    /**
     * Check security compliance
     */
    private function checkSecurityCompliance()
    {
        echo "🔒 Checking Security Compliance...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php'], 'app');
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for SQL injection vulnerabilities
            $this->checkSqlInjection($content, $relativePath);
            
            // Check for XSS vulnerabilities
            $this->checkXssVulnerabilities($content, $relativePath);
            
            // Check for input validation
            $this->checkInputValidation($content, $relativePath);
        }
    }

    /**
     * Check quality compliance
     */
    private function checkQualityCompliance()
    {
        echo "⭐ Checking Quality Compliance...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php'], 'app');
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for code complexity
            $this->checkCodeComplexity($content, $relativePath);
            
            // Check for proper abstraction
            $this->checkAbstraction($content, $relativePath);
        }
    }

    /**
     * Check CSS quality
     */
    private function checkCssQuality($content, $file)
    {
        // Check for too simple CSS (low quality)
        $cssRules = preg_match_all('/[^{]+\{[^}]+\}/', $content);
        if ($cssRules < 10) {
            $this->addResult($file, 'Low quality CSS - too few rules', 'CSS_VIOLATION');
        }
        
        // Check for basic selectors only
        $basicSelectors = preg_match_all('/^[a-zA-Z]+$/', $content);
        if ($basicSelectors > $cssRules * 0.8) {
            $this->addResult($file, 'CSS too basic - lacks advanced selectors', 'CSS_VIOLATION');
        }
    }

    /**
     * Check duplicate CSS rules
     */
    private function checkDuplicateCssRules($content, $file)
    {
        $rules = [];
        if (preg_match_all('/\.([a-zA-Z0-9_-]+)\s*\{/', $content, $matches)) {
            foreach ($matches[1] as $rule) {
                if (isset($rules[$rule])) {
                    $this->addResult($file, "Duplicate CSS rule: .$rule", 'CSS_VIOLATION');
                }
                $rules[$rule] = true;
            }
        }
    }

    /**
     * Check CSS validation
     */
    private function checkCssValidation($content, $file)
    {
        // Check for invalid CSS syntax
        if (preg_match('/[^{]*\{[^}]*\{/', $content)) {
            $this->addResult($file, 'Invalid CSS syntax - nested braces', 'CSS_VIOLATION');
        }
    }

    /**
     * Check progressive enhancement
     */
    private function checkProgressiveEnhancement($content, $file)
    {
        // Check for graceful degradation
        if (!preg_match('/addEventListener|onload|DOMContentLoaded/', $content)) {
            $this->addResult($file, 'Missing progressive enhancement - no event listeners', 'JS_VIOLATION');
        }
    }

    /**
     * Check JavaScript complexity
     */
    private function checkJsComplexity($content, $file)
    {
        $functions = preg_match_all('/function\s+\w+/', $content);
        $classes = preg_match_all('/class\s+\w+/', $content);
        
        if ($functions < 3 && $classes < 1) {
            $this->addResult($file, 'JavaScript too simple - lacks complexity', 'JS_VIOLATION');
        }
    }

    /**
     * Check JavaScript implementation
     */
    private function checkJsImplementation($content, $file)
    {
        // Check for proper error handling
        if (!preg_match('/try\s*\{|catch\s*\(/', $content)) {
            $this->addResult($file, 'Missing error handling in JavaScript', 'JS_VIOLATION');
        }
    }

    /**
     * Check PSR-12 compliance
     */
    private function checkPsr12Compliance($content, $file)
    {
        // Check for proper indentation
        if (preg_match('/^\s*\t/', $content)) {
            $this->addResult($file, 'Mixed tabs and spaces - PSR-12 violation', 'PHP_VIOLATION');
        }
        
        // Check for proper line endings
        if (preg_match('/\r\n/', $content)) {
            $this->addResult($file, 'Windows line endings - PSR-12 violation', 'PHP_VIOLATION');
        }
    }

    /**
     * Check logging compliance
     */
    private function checkLoggingCompliance($content, $file)
    {
        // Check for Log::info in success operations
        if (preg_match('/Log::info\s*\([^)]*success[^)]*\)|Log::info\s*\([^)]*completed[^)]*\)|Log::info\s*\([^)]*created[^)]*\)|Log::info\s*\([^)]*updated[^)]*\)|Log::info\s*\([^)]*deleted[^)]*\)/i', $content)) {
            $this->addResult($file, 'Log::info for success operations found', 'PHP_VIOLATION');
        }
    }

    /**
     * Check feature complexity
     */
    private function checkFeatureComplexity($content, $file)
    {
        $methods = preg_match_all('/public\s+function\s+\w+/', $content);
        $classes = preg_match_all('/class\s+\w+/', $content);
        
        if ($methods < 5 && $classes < 2) {
            $this->addResult($file, 'Insufficient features - too simple', 'PHP_VIOLATION');
        }
    }

    /**
     * Check documentation quality
     */
    private function checkDocumentationQuality($content, $file)
    {
        $methods = preg_match_all('/public\s+function\s+\w+/', $content);
        $phpdoc = preg_match_all('/\/\*\*[\s\S]*?\*\/\s*public\s+function/', $content);
        
        if ($methods > 0 && $phpdoc / $methods < 0.5) {
            $this->addResult($file, 'Insufficient PHPDoc documentation', 'PHP_VIOLATION');
        }
    }

    /**
     * Check integration ease
     */
    private function checkIntegrationEase($content, $file)
    {
        // Check for config files
        if (strpos($file, 'config/') !== false) {
            if (!preg_match('/return\s*\[/', $content)) {
                $this->addResult($file, 'Invalid config file structure', 'PHP_VIOLATION');
            }
        }
    }

    /**
     * Check inline CSS
     */
    private function checkInlineCss($content, $file)
    {
        if (preg_match('/style\s*=\s*["\'][^"\']*["\']/', $content)) {
            $this->addResult($file, 'Inline CSS found', 'BLADE_VIOLATION');
        }
    }

    /**
     * Check inline JavaScript
     */
    private function checkInlineJs($content, $file)
    {
        if (preg_match('/<script[^>]*>[\s\S]*?<\/script>/', $content)) {
            $this->addResult($file, 'Inline JavaScript found', 'BLADE_VIOLATION');
        }
    }

    /**
     * Check @push directives
     */
    private function checkPushDirectives($content, $file)
    {
        if (preg_match('/@push\s*\([\'"](styles|scripts)[\'"]/', $content)) {
            $this->addResult($file, '@push directive found', 'BLADE_VIOLATION');
        }
    }

    /**
     * Check SVG icons
     */
    private function checkSvgIcons($content, $file)
    {
        if (preg_match('/<svg[\s\S]*?<\/svg>/', $content)) {
            $this->addResult($file, 'SVG icons found - use FontAwesome', 'BLADE_VIOLATION');
        }
    }

    /**
     * Check block elements in inline elements
     */
    private function checkBlockInInline($content, $file)
    {
        if (preg_match('/<(span|em)[^>]*>[\s\S]*?<(div|h[1-6]|p)[^>]*>/', $content)) {
            $this->addResult($file, 'Block elements inside inline elements', 'BLADE_VIOLATION');
        }
    }

    /**
     * Check SQL injection vulnerabilities
     */
    private function checkSqlInjection($content, $file)
    {
        if (preg_match('/DB::raw\s*\([\'"][^\'"]*\$[^\'"]*[\'"]/', $content)) {
            $this->addResult($file, 'Potential SQL injection vulnerability', 'SECURITY_ISSUE');
        }
    }

    /**
     * Check XSS vulnerabilities
     */
    private function checkXssVulnerabilities($content, $file)
    {
        if (preg_match('/echo\s+\$[^;]*[^;]*;|print\s+\$[^;]*[^;]*;/', $content)) {
            $this->addResult($file, 'Potential XSS vulnerability - unescaped output', 'SECURITY_ISSUE');
        }
    }

    /**
     * Check input validation
     */
    private function checkInputValidation($content, $file)
    {
        if (preg_match('/\$request->[a-zA-Z]+\([^)]*\)/', $content) && !preg_match('/validate|rules/', $content)) {
            $this->addResult($file, 'Missing input validation', 'SECURITY_ISSUE');
        }
    }

    /**
     * Check code complexity
     */
    private function checkCodeComplexity($content, $file)
    {
        $lines = substr_count($content, "\n") + 1;
        $complexity = preg_match_all('/if\s*\(|foreach\s*\(|while\s*\(|for\s*\(/', $content);
        
        if ($lines > 200 && $complexity < 5) {
            $this->addResult($file, 'Low code complexity for file size', 'QUALITY_ISSUE');
        }
    }

    /**
     * Check abstraction
     */
    private function checkAbstraction($content, $file)
    {
        if (preg_match('/class\s+\w+/', $content) && !preg_match('/interface\s+\w+|abstract\s+class/', $content)) {
            $this->addResult($file, 'Missing abstraction - no interfaces or abstract classes', 'QUALITY_ISSUE');
        }
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'storage', 'node_modules', 'bootstrap/cache'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($this->projectRoot . '/', '', $filePath);
                
                // Skip files in excluded directories
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . '/') === 0 || $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if ($shouldExclude) {
                    continue;
                }
                
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $filePath;
                }
            }
        }
        
        return $files;
    }

    /**
     * Add result
     */
    private function addResult($file, $message, $type)
    {
        $this->results[] = [
            'file' => $file,
            'message' => $message,
            'type' => $type
        ];
        
        switch ($type) {
            case 'CSS_VIOLATION':
                $this->stats['css_violations']++;
                break;
            case 'JS_VIOLATION':
                $this->stats['js_violations']++;
                break;
            case 'PHP_VIOLATION':
                $this->stats['php_violations']++;
                break;
            case 'BLADE_VIOLATION':
                $this->stats['blade_violations']++;
                break;
            case 'SECURITY_ISSUE':
                $this->stats['security_issues']++;
                break;
            case 'QUALITY_ISSUE':
                $this->stats['quality_issues']++;
                break;
        }
    }

    /**
     * Generate comprehensive report
     */
    private function generateComprehensiveReport()
    {
        echo "\n" . str_repeat("=", 80) . "\n";
        echo "📊 COMPREHENSIVE ENVATO COMPLIANCE AUDIT REPORT\n";
        echo str_repeat("=", 80) . "\n\n";
        
        echo "📈 SUMMARY:\n";
        echo "Total Files Scanned: {$this->stats['total_files']}\n";
        echo "CSS Violations: {$this->stats['css_violations']}\n";
        echo "JavaScript Violations: {$this->stats['js_violations']}\n";
        echo "PHP Violations: {$this->stats['php_violations']}\n";
        echo "Blade Violations: {$this->stats['blade_violations']}\n";
        echo "Security Issues: {$this->stats['security_issues']}\n";
        echo "Quality Issues: {$this->stats['quality_issues']}\n\n";
        
        $totalViolations = $this->stats['css_violations'] + $this->stats['js_violations'] + 
                          $this->stats['php_violations'] + $this->stats['blade_violations'] + 
                          $this->stats['security_issues'] + $this->stats['quality_issues'];
        
        echo "🎯 ENVATO COMPLIANCE SCORE:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($totalViolations == 0) {
            echo "🟢 PERFECT COMPLIANCE (100/100)\n";
            echo "✅ All Envato standards met!\n";
        } elseif ($totalViolations <= 10) {
            echo "🟡 GOOD COMPLIANCE (80-99/100)\n";
            echo "⚠️  Minor issues need attention\n";
        } elseif ($totalViolations <= 25) {
            echo "🟠 FAIR COMPLIANCE (60-79/100)\n";
            echo "⚠️  Several issues need fixing\n";
        } else {
            echo "🔴 POOR COMPLIANCE (0-59/100)\n";
            echo "❌ Major issues need immediate attention\n";
        }
        
        echo "\n🔍 DETAILED VIOLATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        $violationTypes = array_count_values(array_column($this->results, 'type'));
        foreach ($violationTypes as $type => $count) {
            echo "• $type: $count violations\n";
        }
        
        echo "\n📋 TOP VIOLATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        $topViolations = array_slice($this->results, 0, 10);
        foreach ($topViolations as $result) {
            echo "❌ {$result['file']}: {$result['message']}\n";
        }
        
        echo "\n🎯 RECOMMENDATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($this->stats['css_violations'] > 0) {
            echo "• Fix CSS quality and remove duplicates\n";
            echo "• Ensure CSS validates properly\n";
        }
        
        if ($this->stats['js_violations'] > 0) {
            echo "• Implement progressive enhancement\n";
            echo "• Add proper error handling\n";
        }
        
        if ($this->stats['php_violations'] > 0) {
            echo "• Follow PSR-12 standards\n";
            echo "• Remove Log::info for success operations\n";
            echo "• Add comprehensive documentation\n";
        }
        
        if ($this->stats['blade_violations'] > 0) {
            echo "• Remove inline CSS and JavaScript\n";
            echo "• Remove @push directives\n";
            echo "• Replace SVG with FontAwesome icons\n";
        }
        
        if ($this->stats['security_issues'] > 0) {
            echo "• Fix SQL injection vulnerabilities\n";
            echo "• Implement XSS protection\n";
            echo "• Add input validation\n";
        }
        
        if ($this->stats['quality_issues'] > 0) {
            echo "• Improve code complexity\n";
            echo "• Add proper abstraction\n";
        }
        
        echo "\n✅ Comprehensive audit completed!\n";
    }
}

// Run the comprehensive audit
$audit = new EnvatoComprehensiveAudit();
$audit->runAudit();
