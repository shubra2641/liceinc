<?php

/**
 * Envato Compliance Audit Script
 * 
 * This script performs comprehensive analysis of the codebase to identify
 * violations of Envato marketplace standards and general code quality issues.
 * 
 * @package Audit
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class EnvatoAuditScript
{
    private $projectRoot;
    private $results = [];
    private $totalFiles = 0;
    private $totalErrors = 0;
    private $envatoViolations = 0;
    private $generalErrors = 0;

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run the complete audit process
     */
    public function runAudit()
    {
        echo "🔍 Starting Envato Compliance Audit...\n";
        echo "=====================================\n\n";

        $this->checkPhpFiles();
        $this->checkBladeFiles();
        $this->checkCssFiles();
        $this->checkJsFiles();
        $this->checkLanguageFiles();
        $this->checkDatabaseStructure();
        $this->checkSecurityIssues();
        $this->checkPerformanceIssues();

        $this->generateReport();
    }

    /**
     * Check PHP files for violations
     */
    private function checkPhpFiles()
    {
        echo "📁 Checking PHP Files...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php']);
        
        foreach ($phpFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for Log::info in success operations
            if (preg_match('/Log::info.*success|Log::info.*completed|Log::info.*created|Log::info.*updated|Log::info.*deleted/i', $content)) {
                $this->addError($relativePath, 'Log::info for success operations found', 'ENVATO_VIOLATION');
            }
            
            // Check for unused imports
            if (preg_match_all('/^use\s+([^;]+);/m', $content, $matches)) {
                foreach ($matches[1] as $import) {
                    $className = basename(trim($import));
                    if (!preg_match('/\b' . preg_quote($className, '/') . '\b/', $content)) {
                        $this->addError($relativePath, "Unused import: $import", 'GENERAL_ERROR');
                    }
                }
            }
            
            // Check for duplicate code patterns
            if (preg_match_all('/DB::beginTransaction\(\)/', $content, $matches)) {
                if (count($matches[0]) > 1) {
                    $this->addError($relativePath, 'Duplicate DB transaction patterns found', 'GENERAL_ERROR');
                }
            }
            
            // Check for missing PHPDoc in methods
            if (preg_match_all('/public\s+function\s+\w+\([^)]*\)\s*\{/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $offset = $match[1];
                    $beforeMethod = substr($content, max(0, $offset - 500), 500);
                    if (!preg_match('/\/\*\*[\s\S]*?\*\/\s*$/', $beforeMethod)) {
                        $this->addError($relativePath, 'Missing PHPDoc for method', 'GENERAL_ERROR');
                    }
                }
            }
            
            // Check for @version, @since, @author in method-level PHPDoc
            if (preg_match('/\/\*\*[\s\S]*?@(version|since|author)[\s\S]*?\*\/\s*(?!class|interface|trait)/', $content)) {
                $this->addError($relativePath, '@version/@since/@author found in method-level PHPDoc', 'ENVATO_VIOLATION');
            }
        }
    }

    /**
     * Check Blade files for violations
     */
    private function checkBladeFiles()
    {
        echo "📁 Checking Blade Files...\n";
        
        $bladeFiles = $this->getFilesByExtension(['.blade.php']);
        
        foreach ($bladeFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for inline CSS
            if (preg_match('/style\s*=\s*["\'][^"\']*["\']/', $content)) {
                $this->addError($relativePath, 'Inline CSS found', 'ENVATO_VIOLATION');
            }
            
            // Check for inline JavaScript
            if (preg_match('/<script[^>]*>[\s\S]*?<\/script>/', $content)) {
                $this->addError($relativePath, 'Inline JavaScript found', 'ENVATO_VIOLATION');
            }
            
            // Check for @push directives
            if (preg_match('/@push\s*\([\'"](styles|scripts)[\'"]\)/', $content)) {
                $this->addError($relativePath, '@push directive found', 'ENVATO_VIOLATION');
            }
            
            // Check for @php blocks
            if (preg_match('/@php[\s\S]*?@endphp/', $content)) {
                $this->addError($relativePath, '@php block found', 'ENVATO_VIOLATION');
            }
            
            // Check for hardcoded text
            if (preg_match('/>[A-Za-z][^<]*</', $content, $matches)) {
                if (!preg_match('/@lang|__\(|{{/', $matches[0])) {
                    $this->addError($relativePath, 'Hardcoded text found', 'ENVATO_VIOLATION');
                }
            }
            
            // Check for SVG icons
            if (preg_match('/<svg[\s\S]*?<\/svg>/', $content)) {
                $this->addError($relativePath, 'SVG icons found (use FontAwesome)', 'ENVATO_VIOLATION');
            }
        }
    }

    /**
     * Check CSS files for violations
     */
    private function checkCssFiles()
    {
        echo "📁 Checking CSS Files...\n";
        
        $cssFiles = $this->getFilesByExtension(['.css', '.scss']);
        
        foreach ($cssFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate CSS rules
            $rules = [];
            if (preg_match_all('/\.([a-zA-Z0-9_-]+)\s*\{[^}]*\}/', $content, $matches)) {
                foreach ($matches[1] as $rule) {
                    if (isset($rules[$rule])) {
                        $this->addError($relativePath, "Duplicate CSS rule: .$rule", 'GENERAL_ERROR');
                    }
                    $rules[$rule] = true;
                }
            }
        }
    }

    /**
     * Check JavaScript files for violations
     */
    private function checkJsFiles()
    {
        echo "📁 Checking JavaScript Files...\n";
        
        $jsFiles = $this->getFilesByExtension(['.js']);
        
        foreach ($jsFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate functions
            if (preg_match_all('/function\s+(\w+)\s*\(/', $content, $matches)) {
                $functions = array_count_values($matches[1]);
                foreach ($functions as $func => $count) {
                    if ($count > 1) {
                        $this->addError($relativePath, "Duplicate function: $func", 'GENERAL_ERROR');
                    }
                }
            }
        }
    }

    /**
     * Check language files for violations
     */
    private function checkLanguageFiles()
    {
        echo "📁 Checking Language Files...\n";
        
        $langFiles = $this->getFilesByExtension(['.php'], 'resources/lang');
        
        foreach ($langFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for HTML in language files
            if (preg_match('/<[^>]+>/', $content)) {
                $this->addError($relativePath, 'HTML found in language file', 'ENVATO_VIOLATION');
            }
            
            // Check for missing language keys
            if (!preg_match('/return\s*\[/', $content)) {
                $this->addError($relativePath, 'Invalid language file structure', 'GENERAL_ERROR');
            }
        }
    }

    /**
     * Check database structure
     */
    private function checkDatabaseStructure()
    {
        echo "📁 Checking Database Structure...\n";
        
        $migrationFiles = $this->getFilesByExtension(['.php'], 'database/migrations');
        
        foreach ($migrationFiles as $file) {
            $this->totalFiles++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for missing indexes
            if (preg_match('/Schema::create\s*\([\'"][^\'"]+[\'"]/', $content) && !preg_match('/->index\(/', $content)) {
                $this->addError($relativePath, 'Missing database indexes', 'GENERAL_ERROR');
            }
        }
    }

    /**
     * Check security issues
     */
    private function checkSecurityIssues()
    {
        echo "📁 Checking Security Issues...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php']);
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for SQL injection vulnerabilities
            if (preg_match('/DB::raw\s*\([\'"][^\'"]*\$[^\'"]*[\'"]/', $content)) {
                $this->addError($relativePath, 'Potential SQL injection vulnerability', 'SECURITY_ERROR');
            }
            
            // Check for missing CSRF protection
            if (preg_match('/Route::post|Route::put|Route::patch|Route::delete/', $content) && !preg_match('/csrf/', $content)) {
                $this->addError($relativePath, 'Missing CSRF protection', 'SECURITY_ERROR');
            }
        }
    }

    /**
     * Check performance issues
     */
    private function checkPerformanceIssues()
    {
        echo "📁 Checking Performance Issues...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php']);
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for N+1 query problems
            if (preg_match('/foreach\s*\([^)]*as[^)]*\)\s*\{[\s\S]*?->[a-zA-Z]+\(\)/', $content)) {
                $this->addError($relativePath, 'Potential N+1 query problem', 'PERFORMANCE_ERROR');
            }
        }
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $file->getPathname();
                }
            }
        }
        
        return $files;
    }

    /**
     * Add error to results
     */
    private function addError($file, $message, $type)
    {
        $this->results[] = [
            'file' => $file,
            'message' => $message,
            'type' => $type
        ];
        
        $this->totalErrors++;
        
        if ($type === 'ENVATO_VIOLATION') {
            $this->envatoViolations++;
        } else {
            $this->generalErrors++;
        }
    }

    /**
     * Generate final report
     */
    private function generateReport()
    {
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📊 ENVATO COMPLIANCE AUDIT REPORT\n";
        echo str_repeat("=", 60) . "\n\n";
        
        echo "📈 SUMMARY:\n";
        echo "Total Files Scanned: {$this->totalFiles}\n";
        echo "Total Errors Found: {$this->totalErrors}\n";
        echo "Envato Violations: {$this->envatoViolations}\n";
        echo "General Errors: {$this->generalErrors}\n\n";
        
        if ($this->envatoViolations > 0) {
            echo "🚨 ENVATO VIOLATIONS:\n";
            echo str_repeat("-", 40) . "\n";
            foreach ($this->results as $result) {
                if ($result['type'] === 'ENVATO_VIOLATION') {
                    echo "❌ {$result['file']}: {$result['message']}\n";
                }
            }
            echo "\n";
        }
        
        if ($this->generalErrors > 0) {
            echo "⚠️  GENERAL ERRORS:\n";
            echo str_repeat("-", 40) . "\n";
            foreach ($this->results as $result) {
                if ($result['type'] !== 'ENVATO_VIOLATION') {
                    echo "⚠️  {$result['file']}: {$result['message']}\n";
                }
            }
            echo "\n";
        }
        
        echo "🎯 RECOMMENDATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($this->envatoViolations > 0) {
            echo "• Fix all Envato violations to meet marketplace standards\n";
            echo "• Remove inline CSS and JavaScript from Blade files\n";
            echo "• Use language system for all text content\n";
            echo "• Remove @push directives and @php blocks\n";
            echo "• Replace SVG icons with FontAwesome\n";
        }
        
        if ($this->generalErrors > 0) {
            echo "• Remove unused imports and functions\n";
            echo "• Add proper PHPDoc documentation\n";
            echo "• Fix duplicate code patterns\n";
            echo "• Implement proper security measures\n";
        }
        
        echo "\n✅ Audit completed successfully!\n";
    }
}

// Run the audit
$audit = new EnvatoAuditScript();
$audit->runAudit();
