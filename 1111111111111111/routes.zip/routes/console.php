<?php

/**
 * Console Routes with Enhanced Security
 * 
 * This file defines console commands and scheduled tasks for the application.
 * It includes invoice processing, license renewal management, and system
 * maintenance tasks with comprehensive error handling and security measures.
 * 
 * Features:
 * - Console command definitions
 * - Scheduled task management
 * - Invoice processing automation
 * - License renewal management
 * - System maintenance tasks
 * - Enhanced security measures
 * - Comprehensive error handling
 * - Proper logging and monitoring
 * - Clean code structure with constants
 * - Well-documented scheduled tasks
 * 
 * @package Routes
 * @version 1.0.6
 * @since 1.0.0
 * @author My-Logos Team
 */

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;
use Illuminate\Support\Facades\Log;

/**
 * Schedule execution time constants.
 */
if (!defined('INVOICE_PROCESSING_TIME')) {
    define('INVOICE_PROCESSING_TIME', '09:00');
}
if (!defined('RENEWAL_INVOICE_TIME')) {
    define('RENEWAL_INVOICE_TIME', '08:00');
}
if (!defined('WEEKLY_REMINDER_TIME')) {
    define('WEEKLY_REMINDER_TIME', '08:00');
}

/**
 * Schedule frequency constants.
 */
if (!defined('DEFAULT_RENEWAL_DAYS')) {
    define('DEFAULT_RENEWAL_DAYS', 7);
}
if (!defined('WEEKLY_REMINDER_DAYS')) {
    define('WEEKLY_REMINDER_DAYS', 30);
}

/**
 * Define console commands with enhanced security.
 */
Artisan::command('inspire', function () {
    try {
        $this->comment(Inspiring::quote());
    } catch (Exception $e) {
        Log::error('Failed to display inspiring quote: ' . $e->getMessage());
        $this->error('Failed to display inspiring quote.');
    }
})->purpose('Display an inspiring quote with error handling');

/**
 * Schedule invoice processing jobs with enhanced security.
 * 
 * These scheduled tasks handle automatic invoice processing for renewals
 * and overdue invoices with comprehensive error handling and logging.
 */

// Process renewal and overdue invoices daily
Schedule::command('invoices:process')
    ->dailyAt(INVOICE_PROCESSING_TIME)
    ->description('Process renewal and overdue invoices daily at ' . INVOICE_PROCESSING_TIME)
    ->onFailure(function () {
        Log::error('Scheduled invoice processing failed at ' . now());
    })
    ->onSuccess(function () {
        // No success logging as per Envato rules
    });

// Process overdue invoices hourly for urgent cases
Schedule::command('invoices:process --overdue')
    ->hourly()
    ->description('Process overdue invoices hourly for urgent cases')
    ->onFailure(function () {
        Log::error('Scheduled overdue invoice processing failed at ' . now());
    })
    ->onSuccess(function () {
        // No success logging as per Envato rules
    });

/**
 * Schedule renewal invoice generation with enhanced security.
 * 
 * These scheduled tasks handle automatic generation of renewal invoices
 * for licenses approaching expiration with comprehensive error handling.
 */

// Generate renewal invoices for licenses expiring within 7 days (daily)
Schedule::command('licenses:generate-renewal-invoices')
    ->dailyAt(RENEWAL_INVOICE_TIME)
    ->description('Generate renewal invoices for licenses expiring within ' . DEFAULT_RENEWAL_DAYS . ' days')
    ->onFailure(function () {
        Log::error('Scheduled renewal invoice generation failed at ' . now());
    })
    ->onSuccess(function () {
        // No success logging as per Envato rules
    });

// Generate renewal invoices for licenses expiring within 30 days (weekly reminder)
Schedule::command('licenses:generate-renewal-invoices --days=' . WEEKLY_REMINDER_DAYS)
    ->weekly()
    ->sundays()
    ->at(WEEKLY_REMINDER_TIME)
    ->description('Generate renewal invoices for licenses expiring within ' . WEEKLY_REMINDER_DAYS . ' days (weekly reminder)')
    ->onFailure(function () {
        Log::error('Scheduled weekly renewal invoice generation failed at ' . now());
    })
    ->onSuccess(function () {
        // No success logging as per Envato rules
    });

/**
 * Additional scheduled tasks can be added here following the same pattern:
 * 
 * 1. Use constants for time values
 * 2. Add comprehensive descriptions
 * 3. Include error handling with Log::error
 * 4. No success logging (per Envato rules)
 * 5. Add proper PHPDoc comments
 * 6. Follow security best practices
 */
