<?php

/**
 * Simple Envato Compliance Audit Script
 * 
 * This script provides a simple and reliable audit of Envato violations
 * without complex processing that might cause errors.
 * 
 * @package Audit
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class SimpleEnvatoAudit
{
    private $projectRoot;
    private $results = [];
    private $stats = [
        'total_files' => 0,
        'envato_violations' => 0,
        'general_errors' => 0,
        'security_issues' => 0,
        'performance_issues' => 0
    ];

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run the audit
     */
    public function runAudit()
    {
        echo "🔍 Simple Envato Compliance Audit\n";
        echo "==================================\n\n";

        $this->checkBladeFiles();
        $this->checkPhpFiles();
        $this->checkCssFiles();
        $this->checkJsFiles();
        $this->checkLanguageFiles();

        $this->generateReport();
    }

    /**
     * Check Blade files
     */
    private function checkBladeFiles()
    {
        echo "📁 Checking Blade Files...\n";
        
        $bladeFiles = $this->getFilesByExtension(['.blade.php'], 'resources/views');
        
        foreach ($bladeFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for inline CSS
            if (preg_match('/style\s*=\s*["\'][^"\']*["\']/', $content)) {
                $this->addResult($relativePath, 'Inline CSS found', 'ENVATO_VIOLATION');
            }
            
            // Check for inline JavaScript
            if (preg_match('/<script[^>]*>[\s\S]*?<\/script>/', $content)) {
                $this->addResult($relativePath, 'Inline JavaScript found', 'ENVATO_VIOLATION');
            }
            
            // Check for @push directives
            if (preg_match('/@push\s*\([\'"](styles|scripts)[\'"]/', $content)) {
                $this->addResult($relativePath, '@push directive found', 'ENVATO_VIOLATION');
            }
            
            // Check for @php blocks
            if (preg_match('/@php[\s\S]*?@endphp/', $content)) {
                $this->addResult($relativePath, '@php block found', 'ENVATO_VIOLATION');
            }
            
            // Check for hardcoded text (simple check)
            if (preg_match('/>[A-Za-z][^<]*?</', $content, $matches)) {
                foreach ($matches as $match) {
                    if (!preg_match('/@lang|__\(|{{/', $match)) {
                        $this->addResult($relativePath, 'Hardcoded text found: ' . substr($match, 0, 50), 'ENVATO_VIOLATION');
                        break; // Only report once per file
                    }
                }
            }
            
            // Check for SVG icons
            if (preg_match('/<svg[\s\S]*?<\/svg>/', $content)) {
                $this->addResult($relativePath, 'SVG icons found (use FontAwesome)', 'ENVATO_VIOLATION');
            }
        }
    }

    /**
     * Check PHP files
     */
    private function checkPhpFiles()
    {
        echo "📁 Checking PHP Files...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php'], 'app');
        
        foreach ($phpFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for Log::info in success operations
            if (preg_match('/Log::info\s*\([^)]*success[^)]*\)|Log::info\s*\([^)]*completed[^)]*\)|Log::info\s*\([^)]*created[^)]*\)|Log::info\s*\([^)]*updated[^)]*\)|Log::info\s*\([^)]*deleted[^)]*\)/i', $content)) {
                $this->addResult($relativePath, 'Log::info for success operations found', 'ENVATO_VIOLATION');
            }
            
            // Check for unused imports (simple check)
            if (preg_match_all('/^use\s+([^;]+);/m', $content, $matches)) {
                foreach ($matches[1] as $import) {
                    $className = basename(trim($import));
                    if (!preg_match('/\b' . preg_quote($className, '/') . '\b/', $content)) {
                        $this->addResult($relativePath, "Unused import: $import", 'GENERAL_ERROR');
                    }
                }
            }
            
            // Check for duplicate DB transactions
            if (preg_match_all('/DB::beginTransaction\(\)/', $content, $matches)) {
                if (count($matches[0]) > 1) {
                    $this->addResult($relativePath, 'Duplicate DB transaction patterns found', 'GENERAL_ERROR');
                }
            }
            
            // Check for missing PHPDoc in public methods
            if (preg_match_all('/public\s+function\s+\w+\([^)]*\)\s*\{/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $offset = $match[1];
                    $beforeMethod = substr($content, max(0, $offset - 200), 200);
                    if (!preg_match('/\/\*\*[\s\S]*?\*\/\s*$/', $beforeMethod)) {
                        $this->addResult($relativePath, 'Missing PHPDoc for public method', 'GENERAL_ERROR');
                        break; // Only report once per file
                    }
                }
            }
            
            // Check for @version/@since/@author in method PHPDoc
            if (preg_match('/\/\*\*[\s\S]*?@(version|since|author)[\s\S]*?\*\/\s*(?!class|interface|trait)/', $content)) {
                $this->addResult($relativePath, '@version/@since/@author found in method-level PHPDoc', 'ENVATO_VIOLATION');
            }
        }
    }

    /**
     * Check CSS files
     */
    private function checkCssFiles()
    {
        echo "📁 Checking CSS Files...\n";
        
        $cssFiles = $this->getFilesByExtension(['.css', '.scss'], 'public/assets');
        
        foreach ($cssFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate CSS rules (simple check)
            $rules = [];
            if (preg_match_all('/\.([a-zA-Z0-9_-]+)\s*\{/', $content, $matches)) {
                foreach ($matches[1] as $rule) {
                    if (isset($rules[$rule])) {
                        $this->addResult($relativePath, "Duplicate CSS rule: .$rule", 'GENERAL_ERROR');
                        break; // Only report once per file
                    }
                    $rules[$rule] = true;
                }
            }
        }
    }

    /**
     * Check JavaScript files
     */
    private function checkJsFiles()
    {
        echo "📁 Checking JavaScript Files...\n";
        
        $jsFiles = $this->getFilesByExtension(['.js'], 'public/assets');
        
        foreach ($jsFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate functions (simple check)
            $functions = [];
            if (preg_match_all('/function\s+(\w+)\s*\(/', $content, $matches)) {
                foreach ($matches[1] as $func) {
                    if (isset($functions[$func])) {
                        $this->addResult($relativePath, "Duplicate function: $func", 'GENERAL_ERROR');
                        break; // Only report once per file
                    }
                    $functions[$func] = true;
                }
            }
        }
    }

    /**
     * Check language files
     */
    private function checkLanguageFiles()
    {
        echo "📁 Checking Language Files...\n";
        
        $langFiles = $this->getFilesByExtension(['.php'], 'resources/lang');
        
        foreach ($langFiles as $file) {
            $this->stats['total_files']++;
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for HTML in language files
            if (preg_match('/<[^>]+>/', $content)) {
                $this->addResult($relativePath, 'HTML found in language file', 'ENVATO_VIOLATION');
            }
            
            // Check for missing return statement
            if (!preg_match('/return\s*\[/', $content)) {
                $this->addResult($relativePath, 'Invalid language file structure', 'GENERAL_ERROR');
            }
        }
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'storage', 'node_modules', 'bootstrap/cache'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($this->projectRoot . '/', '', $filePath);
                
                // Skip files in excluded directories
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . '/') === 0 || $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if ($shouldExclude) {
                    continue;
                }
                
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $filePath;
                }
            }
        }
        
        return $files;
    }

    /**
     * Add result
     */
    private function addResult($file, $message, $type)
    {
        $this->results[] = [
            'file' => $file,
            'message' => $message,
            'type' => $type
        ];
        
        if ($type === 'ENVATO_VIOLATION') {
            $this->stats['envato_violations']++;
        } else {
            $this->stats['general_errors']++;
        }
    }

    /**
     * Generate report
     */
    private function generateReport()
    {
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📊 ENVATO COMPLIANCE AUDIT REPORT\n";
        echo str_repeat("=", 60) . "\n\n";
        
        echo "📈 SUMMARY:\n";
        echo "Total Files Scanned: {$this->stats['total_files']}\n";
        echo "Envato Violations: {$this->stats['envato_violations']}\n";
        echo "General Errors: {$this->stats['general_errors']}\n\n";
        
        if ($this->stats['envato_violations'] > 0) {
            echo "🚨 ENVATO VIOLATIONS:\n";
            echo str_repeat("-", 40) . "\n";
            foreach ($this->results as $result) {
                if ($result['type'] === 'ENVATO_VIOLATION') {
                    echo "❌ {$result['file']}: {$result['message']}\n";
                }
            }
            echo "\n";
        }
        
        if ($this->stats['general_errors'] > 0) {
            echo "⚠️  GENERAL ERRORS:\n";
            echo str_repeat("-", 40) . "\n";
            foreach ($this->results as $result) {
                if ($result['type'] !== 'ENVATO_VIOLATION') {
                    echo "⚠️  {$result['file']}: {$result['message']}\n";
                }
            }
            echo "\n";
        }
        
        echo "🎯 RECOMMENDATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        if ($this->stats['envato_violations'] > 0) {
            echo "• Fix all Envato violations to meet marketplace standards\n";
            echo "• Remove inline CSS and JavaScript from Blade files\n";
            echo "• Use language system for all text content\n";
            echo "• Remove @push directives and @php blocks\n";
            echo "• Replace SVG icons with FontAwesome\n";
        }
        
        if ($this->stats['general_errors'] > 0) {
            echo "• Remove unused imports and functions\n";
            echo "• Add proper PHPDoc documentation\n";
            echo "• Fix duplicate code patterns\n";
        }
        
        echo "\n✅ Audit completed successfully!\n";
    }
}

// Run the audit
$audit = new SimpleEnvatoAudit();
$audit->runAudit();
