<?php

/**
 * Detailed Envato Compliance Audit Script
 * 
 * This script provides detailed analysis of Envato marketplace violations
 * with specific recommendations and fix suggestions.
 * 
 * @package Audit
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class DetailedEnvatoAudit
{
    private $projectRoot;
    private $violations = [];
    private $fixes = [];

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run detailed audit
     */
    public function runDetailedAudit()
    {
        echo "🔍 Detailed Envato Compliance Audit\n";
        echo "=====================================\n\n";

        $this->checkBladeCompliance();
        $this->checkPhpCompliance();
        $this->checkCssCompliance();
        $this->checkJsCompliance();
        $this->checkLanguageCompliance();
        $this->checkSecurityCompliance();
        $this->checkQualityCompliance();

        $this->generateDetailedReport();
    }

    /**
     * Check Blade file compliance
     */
    private function checkBladeCompliance()
    {
        echo "📁 Checking Blade Compliance...\n";
        
        $bladeFiles = $this->getBladeFiles();
        
        foreach ($bladeFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for inline CSS violations
            if (preg_match_all('/style\s*=\s*["\']([^"\']*)["\']/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'INLINE_CSS', $match[0], $match[1], 
                        'Move CSS to external file in public/assets/css/');
                }
            }
            
            // Check for inline JavaScript violations
            if (preg_match_all('/<script[^>]*>([\s\S]*?)<\/script>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'INLINE_JS', $match[0], $match[1], 
                        'Move JavaScript to external file in public/assets/js/');
                }
            }
            
            // Check for @push violations
            if (preg_match_all('/@push\s*\([\'"](styles|scripts)[\'"][\s\S]*?@endpush/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'PUSH_DIRECTIVE', $match[0], $match[1], 
                        'Remove @push directives and use external files');
                }
            }
            
            // Check for @php violations
            if (preg_match_all('/@php[\s\S]*?@endphp/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'PHP_BLOCK', $match[0], $match[1], 
                        'Remove @php blocks and move logic to controllers');
                }
            }
            
            // Check for hardcoded text violations
            if (preg_match_all('/>([A-Za-z][^<]*?)</', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[1] as $index => $text) {
                    $text = trim($text);
                    if (strlen($text) > 3 && !preg_match('/@lang|__\(|{{/', $text)) {
                        $this->addViolation($relativePath, 'HARDCODED_TEXT', $text, $matches[0][$index][1], 
                            'Use language system: @lang(\'key\') or __(\'key\')');
                    }
                }
            }
            
            // Check for SVG icon violations
            if (preg_match_all('/<svg[\s\S]*?<\/svg>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'SVG_ICON', $match[0], $match[1], 
                        'Replace with FontAwesome: <i class="fas fa-icon"></i>');
                }
            }
        }
    }

    /**
     * Check PHP file compliance
     */
    private function checkPhpCompliance()
    {
        echo "📁 Checking PHP Compliance...\n";
        
        $phpFiles = $this->getPhpFiles();
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for Log::info violations
            if (preg_match_all('/Log::info\s*\([^)]*success[^)]*\)|Log::info\s*\([^)]*completed[^)]*\)|Log::info\s*\([^)]*created[^)]*\)|Log::info\s*\([^)]*updated[^)]*\)|Log::info\s*\([^)]*deleted[^)]*\)/i', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'SUCCESS_LOGGING', $match[0], $match[1], 
                        'Remove Log::info for success operations (only log errors)');
                }
            }
            
            // Check for unused imports
            if (preg_match_all('/^use\s+([^;]+);/m', $content, $matches)) {
                foreach ($matches[1] as $import) {
                    $className = basename(trim($import));
                    if (!preg_match('/\b' . preg_quote($className, '/') . '\b/', $content)) {
                        $this->addViolation($relativePath, 'UNUSED_IMPORT', $import, 0, 
                            'Remove unused import: ' . $import);
                    }
                }
            }
            
            // Check for duplicate code patterns
            if (preg_match_all('/DB::beginTransaction\(\)/', $content, $matches)) {
                if (count($matches[0]) > 1) {
                    $this->addViolation($relativePath, 'DUPLICATE_CODE', 'Multiple DB transactions', 0, 
                        'Consolidate duplicate transaction patterns');
                }
            }
            
            // Check for missing PHPDoc
            if (preg_match_all('/public\s+function\s+(\w+)\s*\([^)]*\)\s*\{/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $methodName = $matches[1][$index];
                    $offset = $match[1];
                    $beforeMethod = substr($content, max(0, $offset - 500), 500);
                    if (!preg_match('/\/\*\*[\s\S]*?\*\/\s*$/', $beforeMethod)) {
                        $this->addViolation($relativePath, 'MISSING_PHPDOC', $methodName, $offset, 
                            'Add PHPDoc documentation for method: ' . $methodName);
                    }
                }
            }
            
            // Check for @version/@since/@author in method PHPDoc
            if (preg_match_all('/\/\*\*[\s\S]*?@(version|since|author)[\s\S]*?\*\/\s*(?!class|interface|trait)/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'METHOD_VERSION_TAG', $match[0], $match[1], 
                        'Remove @version/@since/@author from method-level PHPDoc');
                }
            }
        }
    }

    /**
     * Check CSS compliance
     */
    private function checkCssCompliance()
    {
        echo "📁 Checking CSS Compliance...\n";
        
        $cssFiles = $this->getCssFiles();
        
        foreach ($cssFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate CSS rules
            $rules = [];
            if (preg_match_all('/\.([a-zA-Z0-9_-]+)\s*\{[^}]*\}/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[1] as $index => $rule) {
                    if (isset($rules[$rule])) {
                        $this->addViolation($relativePath, 'DUPLICATE_CSS_RULE', $rule, $matches[0][$index][1], 
                            'Remove duplicate CSS rule: .' . $rule);
                    }
                    $rules[$rule] = true;
                }
            }
        }
    }

    /**
     * Check JavaScript compliance
     */
    private function checkJsCompliance()
    {
        echo "📁 Checking JavaScript Compliance...\n";
        
        $jsFiles = $this->getJsFiles();
        
        foreach ($jsFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for duplicate functions
            if (preg_match_all('/function\s+(\w+)\s*\(/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                $functions = [];
                foreach ($matches[1] as $index => $func) {
                    if (isset($functions[$func])) {
                        $this->addViolation($relativePath, 'DUPLICATE_FUNCTION', $func, $matches[0][$index][1], 
                            'Remove duplicate function: ' . $func);
                    }
                    $functions[$func] = true;
                }
            }
        }
    }

    /**
     * Check language compliance
     */
    private function checkLanguageCompliance()
    {
        echo "📁 Checking Language Compliance...\n";
        
        $langFiles = $this->getLanguageFiles();
        
        foreach ($langFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for HTML in language files
            if (preg_match_all('/<[^>]+>/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'HTML_IN_LANG_FILE', $match[0], $match[1], 
                        'Remove HTML from language files, use placeholders');
                }
            }
            
            // Check for missing return statement
            if (!preg_match('/return\s*\[/', $content)) {
                $this->addViolation($relativePath, 'INVALID_LANG_STRUCTURE', 'Missing return statement', 0, 
                        'Add return statement to language file');
            }
        }
    }

    /**
     * Check security compliance
     */
    private function checkSecurityCompliance()
    {
        echo "📁 Checking Security Compliance...\n";
        
        $phpFiles = $this->getPhpFiles();
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for SQL injection vulnerabilities
            if (preg_match_all('/DB::raw\s*\([\'"][^\'"]*\$[^\'"]*[\'"]/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'SQL_INJECTION_RISK', $match[0], $match[1], 
                        'Use parameterized queries instead of raw SQL with variables');
                }
            }
            
            // Check for missing CSRF protection
            if (preg_match_all('/Route::(post|put|patch|delete)/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    if (!preg_match('/csrf/', $content)) {
                        $this->addViolation($relativePath, 'MISSING_CSRF', $match[0], $match[1], 
                            'Add CSRF protection to form routes');
                    }
                }
            }
        }
    }

    /**
     * Check quality compliance
     */
    private function checkQualityCompliance()
    {
        echo "📁 Checking Quality Compliance...\n";
        
        $phpFiles = $this->getPhpFiles();
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $relativePath = str_replace($this->projectRoot . '/', '', $file);
            
            // Check for N+1 query problems
            if (preg_match_all('/foreach\s*\([^)]*as[^)]*\)\s*\{[\s\S]*?->[a-zA-Z]+\(\)/', $content, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $index => $match) {
                    $this->addViolation($relativePath, 'N_PLUS_1_QUERY', $match[0], $match[1], 
                        'Use eager loading to prevent N+1 queries');
                }
            }
        }
    }

    /**
     * Get Blade files
     */
    private function getBladeFiles()
    {
        return $this->getFilesByExtension(['.blade.php'], 'resources/views');
    }

    /**
     * Get PHP files
     */
    private function getPhpFiles()
    {
        return $this->getFilesByExtension(['.php'], 'app');
    }

    /**
     * Get CSS files
     */
    private function getCssFiles()
    {
        return $this->getFilesByExtension(['.css', '.scss'], 'public/assets');
    }

    /**
     * Get JavaScript files
     */
    private function getJsFiles()
    {
        return $this->getFilesByExtension(['.js'], 'public/assets');
    }

    /**
     * Get language files
     */
    private function getLanguageFiles()
    {
        return $this->getFilesByExtension(['.php'], 'resources/lang');
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $file->getPathname();
                }
            }
        }
        
        return $files;
    }

    /**
     * Add violation
     */
    private function addViolation($file, $type, $code, $position, $fix)
    {
        $this->violations[] = [
            'file' => $file,
            'type' => $type,
            'code' => $code,
            'position' => $position,
            'fix' => $fix
        ];
    }

    /**
     * Generate detailed report
     */
    private function generateDetailedReport()
    {
        echo "\n" . str_repeat("=", 80) . "\n";
        echo "📊 DETAILED ENVATO COMPLIANCE AUDIT REPORT\n";
        echo str_repeat("=", 80) . "\n\n";
        
        $violationTypes = array_count_values(array_column($this->violations, 'type'));
        
        echo "📈 VIOLATION SUMMARY:\n";
        echo str_repeat("-", 40) . "\n";
        foreach ($violationTypes as $type => $count) {
            echo "• $type: $count violations\n";
        }
        echo "\n";
        
        echo "🔍 DETAILED VIOLATIONS:\n";
        echo str_repeat("-", 40) . "\n";
        
        foreach ($this->violations as $violation) {
            echo "❌ {$violation['file']}\n";
            echo "   Type: {$violation['type']}\n";
            echo "   Code: {$violation['code']}\n";
            echo "   Fix: {$violation['fix']}\n";
            echo "\n";
        }
        
        echo "🛠️  AUTOMATED FIXES:\n";
        echo str_repeat("-", 40) . "\n";
        echo "• Run: php envato-fix.php to apply automatic fixes\n";
        echo "• Review all changes before committing\n";
        echo "• Test functionality after fixes\n\n";
        
        echo "✅ Detailed audit completed!\n";
    }
}

// Run the detailed audit
$audit = new DetailedEnvatoAudit();
$audit->runDetailedAudit();
