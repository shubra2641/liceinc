<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class AdvancedWebhookServiceTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_example(): void
    {
        $this->assertTrue(true);
    }
}
