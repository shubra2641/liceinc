<?php

namespace Tests\Unit\Requests\Admin;

use App\Http\Requests\Admin\StoreLicenseRequest;
use App\Models\User;
use App\Models\Product;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

/**
 * Test suite for StoreLicenseRequest
 * 
 * This test suite covers all validation rules, authorization,
 * and data preparation for license creation requests.
 * 
 * @package Tests\Unit\Requests\Admin
 
 */
class StoreLicenseRequestTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;
    protected User $user;
    protected Product $product;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->admin = User::factory()->create();
        $this->admin->assignRole('admin');
        
        $this->user = User::factory()->create();
        $this->product = Product::factory()->create();
    }

    /** @test */
    public function admin_can_authorize_request()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        $this->assertTrue($request->authorize());
    }

    /** @test */
    public function non_admin_cannot_authorize_request()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->user);

        $this->assertFalse($request->authorize());
    }

    /** @test */
    public function guest_cannot_authorize_request()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => null);

        $this->assertFalse($request->authorize());
    }

    /** @test */
    public function validates_required_fields()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        $validator = Validator::make([], $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('user_id', $validator->errors()->toArray());
        $this->assertArrayHasKey('product_id', $validator->errors()->toArray());
        $this->assertArrayHasKey('status', $validator->errors()->toArray());
        $this->assertArrayHasKey('invoice_payment_status', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_user_id_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid user ID
        $validData = ['user_id' => $this->user->id];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test invalid user ID
        $invalidData = ['user_id' => 99999];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('user_id', $validator->errors()->toArray());

        // Test non-integer user ID
        $invalidData = ['user_id' => 'invalid'];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('user_id', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_product_id_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid product ID
        $validData = ['product_id' => $this->product->id];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test invalid product ID
        $invalidData = ['product_id' => 99999];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('product_id', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_license_type_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid license types
        $validTypes = ['single', 'multi', 'developer', 'extended'];
        foreach ($validTypes as $type) {
            $validData = ['license_type' => $type];
            $validator = Validator::make($validData, $request->rules(), $request->messages());
            $this->assertFalse($validator->fails());
        }

        // Test invalid license type
        $invalidData = ['license_type' => 'invalid_type'];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('license_type', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_status_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid statuses
        $validStatuses = ['active', 'inactive', 'suspended', 'expired'];
        foreach ($validStatuses as $status) {
            $validData = ['status' => $status];
            $validator = Validator::make($validData, $request->rules(), $request->messages());
            $this->assertFalse($validator->fails());
        }

        // Test invalid status
        $invalidData = ['status' => 'invalid_status'];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('status', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_max_domains_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid max domains
        $validData = ['max_domains' => 5];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test max domains too small
        $invalidData = ['max_domains' => 0];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('max_domains', $validator->errors()->toArray());

        // Test max domains too large
        $invalidData = ['max_domains' => 1001];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('max_domains', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_license_expires_at_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid future date
        $validData = ['license_expires_at' => now()->addDays(30)->format('Y-m-d')];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test past date
        $invalidData = ['license_expires_at' => now()->subDays(1)->format('Y-m-d')];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('license_expires_at', $validator->errors()->toArray());

        // Test invalid date format
        $invalidData = ['license_expires_at' => 'invalid-date'];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('license_expires_at', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_notes_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid notes
        $validData = ['notes' => 'Valid notes'];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test notes too long
        $invalidData = ['notes' => str_repeat('a', 1001)];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('notes', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_invoice_payment_status_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid payment statuses
        $validStatuses = ['paid', 'pending'];
        foreach ($validStatuses as $status) {
            $validData = ['invoice_payment_status' => $status];
            $validator = Validator::make($validData, $request->rules(), $request->messages());
            $this->assertFalse($validator->fails());
        }

        // Test invalid payment status
        $invalidData = ['invoice_payment_status' => 'invalid_status'];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('invoice_payment_status', $validator->errors()->toArray());
    }

    /** @test */
    public function validates_invoice_due_date_field()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        // Test valid future date
        $validData = ['invoice_due_date' => now()->addDays(30)->format('Y-m-d')];
        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());

        // Test past date
        $invalidData = ['invoice_due_date' => now()->subDays(1)->format('Y-m-d')];
        $validator = Validator::make($invalidData, $request->rules(), $request->messages());
        $this->assertTrue($validator->fails());
        $this->assertArrayHasKey('invoice_due_date', $validator->errors()->toArray());
    }

    /** @test */
    public function allows_null_optional_fields()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        $validData = [
            'user_id' => $this->user->id,
            'product_id' => $this->product->id,
            'status' => 'active',
            'invoice_payment_status' => 'paid',
        ];

        $validator = Validator::make($validData, $request->rules(), $request->messages());
        $this->assertFalse($validator->fails());
    }

    /** @test */
    public function prepares_data_for_validation()
    {
        $request = new StoreLicenseRequest();
        $request->setUserResolver(fn() => $this->admin);

        $data = [
            'user_id' => '123',
            'product_id' => '456',
            'max_domains' => '5',
            'license_key' => '  test-key  ',
            'license_type' => '  single  ',
            'status' => '  active  ',
            'notes' => '  test notes  ',
            'invoice_payment_status' => '  paid  ',
        ];

        $request->replace($data);
        $request->prepareForValidation();

        $this->assertEquals(123, $request->input('user_id'));
        $this->assertEquals(456, $request->input('product_id'));
        $this->assertEquals(5, $request->input('max_domains'));
        $this->assertEquals('test-key', $request->input('license_key'));
        $this->assertEquals('single', $request->input('license_type'));
        $this->assertEquals('active', $request->input('status'));
        $this->assertEquals('test notes', $request->input('notes'));
        $this->assertEquals('paid', $request->input('invoice_payment_status'));
    }

    /** @test */
    public function has_custom_error_messages()
    {
        $request = new StoreLicenseRequest();
        $messages = $request->messages();

        $this->assertIsArray($messages);
        $this->assertArrayHasKey('user_id.required', $messages);
        $this->assertArrayHasKey('product_id.required', $messages);
        $this->assertArrayHasKey('status.required', $messages);
        $this->assertArrayHasKey('invoice_payment_status.required', $messages);
    }

    /** @test */
    public function has_custom_attributes()
    {
        $request = new StoreLicenseRequest();
        $attributes = $request->attributes();

        $this->assertIsArray($attributes);
        $this->assertArrayHasKey('user_id', $attributes);
        $this->assertArrayHasKey('product_id', $attributes);
        $this->assertArrayHasKey('status', $attributes);
        $this->assertArrayHasKey('invoice_payment_status', $attributes);
    }
}
