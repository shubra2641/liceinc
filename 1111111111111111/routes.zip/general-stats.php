<?php

/**
 * General Statistics Script
 * 
 * This script provides general statistics about the codebase
 * including file counts, code metrics, and project structure.
 * 
 * @package Stats
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class GeneralStats
{
    private $projectRoot;
    private $stats = [];

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
    }

    /**
     * Run statistics collection
     */
    public function runStats()
    {
        echo "📊 General Project Statistics\n";
        echo "==============================\n\n";

        $this->collectFileStats();
        $this->collectCodeStats();
        $this->collectStructureStats();
        $this->collectLanguageStats();

        $this->generateStatsReport();
    }

    /**
     * Collect file statistics
     */
    private function collectFileStats()
    {
        echo "📁 Collecting File Statistics...\n";
        
        $extensions = [
            'php' => ['.php'],
            'blade' => ['.blade.php'],
            'css' => ['.css', '.scss'],
            'js' => ['.js'],
            'html' => ['.html', '.htm'],
            'json' => ['.json'],
            'xml' => ['.xml'],
            'md' => ['.md'],
            'txt' => ['.txt'],
            'sql' => ['.sql']
        ];

        foreach ($extensions as $type => $exts) {
            $files = $this->getFilesByExtension($exts);
            $this->stats['files'][$type] = count($files);
        }

        // Total files
        $this->stats['files']['total'] = array_sum($this->stats['files']);
    }

    /**
     * Collect code statistics
     */
    private function collectCodeStats()
    {
        echo "📝 Collecting Code Statistics...\n";
        
        $phpFiles = $this->getFilesByExtension(['.php'], 'app');
        $bladeFiles = $this->getFilesByExtension(['.blade.php'], 'resources/views');
        
        $totalLines = 0;
        $totalClasses = 0;
        $totalMethods = 0;
        $totalFunctions = 0;
        $totalComments = 0;

        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            $lines = substr_count($content, "\n") + 1;
            $totalLines += $lines;

            // Count classes
            $classes = preg_match_all('/class\s+\w+/', $content);
            $totalClasses += $classes;

            // Count methods
            $methods = preg_match_all('/public\s+function\s+\w+|private\s+function\s+\w+|protected\s+function\s+\w+/', $content);
            $totalMethods += $methods;

            // Count functions
            $functions = preg_match_all('/function\s+\w+/', $content);
            $totalFunctions += $functions;

            // Count comments
            $comments = preg_match_all('/\/\*[\s\S]*?\*\/|\/\/.*/', $content);
            $totalComments += $comments;
        }

        foreach ($bladeFiles as $file) {
            $content = file_get_contents($file);
            $lines = substr_count($content, "\n") + 1;
            $totalLines += $lines;
        }

        $this->stats['code'] = [
            'total_lines' => $totalLines,
            'total_classes' => $totalClasses,
            'total_methods' => $totalMethods,
            'total_functions' => $totalFunctions,
            'total_comments' => $totalComments,
            'avg_lines_per_file' => $this->stats['files']['php'] > 0 ? round($totalLines / $this->stats['files']['php'], 2) : 0
        ];
    }

    /**
     * Collect structure statistics
     */
    private function collectStructureStats()
    {
        echo "🏗️  Collecting Structure Statistics...\n";
        
        $directories = [
            'app' => 'app',
            'config' => 'config',
            'database' => 'database',
            'public' => 'public',
            'resources' => 'resources',
            'routes' => 'routes',
            'storage' => 'storage'
        ];

        foreach ($directories as $name => $path) {
            if (is_dir($this->projectRoot . '/' . $path)) {
                $this->stats['structure'][$name] = $this->countDirectoryFiles($path);
            } else {
                $this->stats['structure'][$name] = 0;
            }
        }
    }

    /**
     * Collect language statistics
     */
    private function collectLanguageStats()
    {
        echo "🌐 Collecting Language Statistics...\n";
        
        $langDirs = ['ar', 'en', 'hi'];
        $this->stats['languages'] = [];

        foreach ($langDirs as $lang) {
            $langPath = "resources/lang/{$lang}";
            if (is_dir($this->projectRoot . '/' . $langPath)) {
                $files = $this->getFilesByExtension(['.php'], $langPath);
                $this->stats['languages'][$lang] = count($files);
            } else {
                $this->stats['languages'][$lang] = 0;
            }
        }
    }

    /**
     * Count files in directory
     */
    private function countDirectoryFiles($directory)
    {
        $path = $this->projectRoot . '/' . $directory;
        if (!is_dir($path)) {
            return 0;
        }

        $count = 0;
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'storage', 'node_modules', 'bootstrap/cache'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($this->projectRoot . '/', '', $filePath);
                
                // Skip files in excluded directories
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . '/') === 0 || $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if ($shouldExclude) {
                    continue;
                }
                
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $filePath;
                }
            }
        }
        
        return $files;
    }

    /**
     * Generate statistics report
     */
    private function generateStatsReport()
    {
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📊 GENERAL PROJECT STATISTICS REPORT\n";
        echo str_repeat("=", 60) . "\n\n";
        
        echo "📁 FILE STATISTICS:\n";
        echo str_repeat("-", 30) . "\n";
        foreach ($this->stats['files'] as $type => $count) {
            if ($type !== 'total') {
                echo "• {$type}: {$count} files\n";
            }
        }
        echo "• Total: {$this->stats['files']['total']} files\n\n";
        
        echo "📝 CODE STATISTICS:\n";
        echo str_repeat("-", 30) . "\n";
        echo "• Total Lines: " . number_format($this->stats['code']['total_lines']) . "\n";
        echo "• Total Classes: " . number_format($this->stats['code']['total_classes']) . "\n";
        echo "• Total Methods: " . number_format($this->stats['code']['total_methods']) . "\n";
        echo "• Total Functions: " . number_format($this->stats['code']['total_functions']) . "\n";
        echo "• Total Comments: " . number_format($this->stats['code']['total_comments']) . "\n";
        echo "• Avg Lines per File: " . $this->stats['code']['avg_lines_per_file'] . "\n\n";
        
        echo "🏗️  STRUCTURE STATISTICS:\n";
        echo str_repeat("-", 30) . "\n";
        foreach ($this->stats['structure'] as $dir => $count) {
            echo "• {$dir}: {$count} files\n";
        }
        echo "\n";
        
        echo "🌐 LANGUAGE STATISTICS:\n";
        echo str_repeat("-", 30) . "\n";
        foreach ($this->stats['languages'] as $lang => $count) {
            echo "• {$lang}: {$count} language files\n";
        }
        echo "\n";
        
        echo "📈 PROJECT HEALTH SCORE:\n";
        echo str_repeat("-", 30) . "\n";
        $healthScore = $this->calculateHealthScore();
        echo "• Overall Health Score: {$healthScore}/100\n";
        
        if ($healthScore >= 80) {
            echo "• Status: 🟢 Excellent\n";
        } elseif ($healthScore >= 60) {
            echo "• Status: 🟡 Good\n";
        } elseif ($healthScore >= 40) {
            echo "• Status: 🟠 Fair\n";
        } else {
            echo "• Status: 🔴 Needs Improvement\n";
        }
        
        echo "\n✅ Statistics collection completed!\n";
    }

    /**
     * Calculate project health score
     */
    private function calculateHealthScore()
    {
        $score = 100;
        
        // Deduct points for missing documentation
        $commentRatio = $this->stats['code']['total_comments'] / max($this->stats['code']['total_lines'], 1);
        if ($commentRatio < 0.1) {
            $score -= 20;
        } elseif ($commentRatio < 0.05) {
            $score -= 30;
        }
        
        // Deduct points for large files
        if ($this->stats['code']['avg_lines_per_file'] > 200) {
            $score -= 15;
        } elseif ($this->stats['code']['avg_lines_per_file'] > 300) {
            $score -= 25;
        }
        
        // Deduct points for too many methods per class
        $avgMethodsPerClass = $this->stats['code']['total_methods'] / max($this->stats['code']['total_classes'], 1);
        if ($avgMethodsPerClass > 20) {
            $score -= 10;
        } elseif ($avgMethodsPerClass > 30) {
            $score -= 20;
        }
        
        return max(0, min(100, $score));
    }
}

// Run the statistics collection
$stats = new GeneralStats();
$stats->runStats();
