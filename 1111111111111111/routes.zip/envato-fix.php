<?php

/**
 * Envato Compliance Auto-Fix Script
 * 
 * This script automatically fixes common Envato violations
 * and code quality issues in the codebase.
 * 
 * @package Fix
 * @version 1.0.0
 * @since 1.0.0
 * @author My-Logos Team
 */

class EnvatoAutoFix
{
    private $projectRoot;
    private $fixesApplied = 0;
    private $backupDir;

    public function __construct($projectRoot = null)
    {
        $this->projectRoot = $projectRoot ?: __DIR__;
        $this->backupDir = $this->projectRoot . '/backups/' . date('Y-m-d_H-i-s');
    }

    /**
     * Run auto-fix process
     */
    public function runAutoFix()
    {
        echo "🔧 Starting Envato Compliance Auto-Fix...\n";
        echo "==========================================\n\n";

        // Create backup directory
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }

        $this->fixBladeFiles();
        $this->fixPhpFiles();
        $this->fixCssFiles();
        $this->fixJsFiles();
        $this->fixLanguageFiles();

        $this->generateFixReport();
    }

    /**
     * Fix Blade files
     */
    private function fixBladeFiles()
    {
        echo "🔧 Fixing Blade Files...\n";
        
        $bladeFiles = $this->getBladeFiles();
        
        foreach ($bladeFiles as $file) {
            $this->backupFile($file);
            $content = file_get_contents($file);
            $originalContent = $content;
            
            // Fix inline CSS
            $content = $this->extractInlineCss($content, $file);
            
            // Fix inline JavaScript
            $content = $this->extractInlineJs($content, $file);
            
            // Fix @push directives
            $content = $this->removePushDirectives($content);
            
            // Fix @php blocks
            $content = $this->removePhpBlocks($content);
            
            // Fix hardcoded text
            $content = $this->fixHardcodedText($content);
            
            // Fix SVG icons
            $content = $this->fixSvgIcons($content);
            
            if ($content !== $originalContent) {
                file_put_contents($file, $content);
                $this->fixesApplied++;
                echo "✅ Fixed: " . str_replace($this->projectRoot . '/', '', $file) . "\n";
            }
        }
    }

    /**
     * Fix PHP files
     */
    private function fixPhpFiles()
    {
        echo "🔧 Fixing PHP Files...\n";
        
        $phpFiles = $this->getPhpFiles();
        
        foreach ($phpFiles as $file) {
            $this->backupFile($file);
            $content = file_get_contents($file);
            $originalContent = $content;
            
            // Fix Log::info for success operations
            $content = $this->removeSuccessLogging($content);
            
            // Fix unused imports
            $content = $this->removeUnusedImports($content);
            
            // Fix duplicate code patterns
            $content = $this->consolidateDuplicateCode($content);
            
            // Fix PHPDoc issues
            $content = $this->fixPhpDocIssues($content);
            
            if ($content !== $originalContent) {
                file_put_contents($file, $content);
                $this->fixesApplied++;
                echo "✅ Fixed: " . str_replace($this->projectRoot . '/', '', $file) . "\n";
            }
        }
    }

    /**
     * Fix CSS files
     */
    private function fixCssFiles()
    {
        echo "🔧 Fixing CSS Files...\n";
        
        $cssFiles = $this->getCssFiles();
        
        foreach ($cssFiles as $file) {
            $this->backupFile($file);
            $content = file_get_contents($file);
            $originalContent = $content;
            
            // Fix duplicate CSS rules
            $content = $this->removeDuplicateCssRules($content);
            
            if ($content !== $originalContent) {
                file_put_contents($file, $content);
                $this->fixesApplied++;
                echo "✅ Fixed: " . str_replace($this->projectRoot . '/', '', $file) . "\n";
            }
        }
    }

    /**
     * Fix JavaScript files
     */
    private function fixJsFiles()
    {
        echo "🔧 Fixing JavaScript Files...\n";
        
        $jsFiles = $this->getJsFiles();
        
        foreach ($jsFiles as $file) {
            $this->backupFile($file);
            $content = file_get_contents($file);
            $originalContent = $content;
            
            // Fix duplicate functions
            $content = $this->removeDuplicateFunctions($content);
            
            if ($content !== $originalContent) {
                file_put_contents($file, $content);
                $this->fixesApplied++;
                echo "✅ Fixed: " . str_replace($this->projectRoot . '/', '', $file) . "\n";
            }
        }
    }

    /**
     * Fix language files
     */
    private function fixLanguageFiles()
    {
        echo "🔧 Fixing Language Files...\n";
        
        $langFiles = $this->getLanguageFiles();
        
        foreach ($langFiles as $file) {
            $this->backupFile($file);
            $content = file_get_contents($file);
            $originalContent = $content;
            
            // Fix HTML in language files
            $content = $this->removeHtmlFromLangFiles($content);
            
            if ($content !== $originalContent) {
                file_put_contents($file, $content);
                $this->fixesApplied++;
                echo "✅ Fixed: " . str_replace($this->projectRoot . '/', '', $file) . "\n";
            }
        }
    }

    /**
     * Extract inline CSS to external file
     */
    private function extractInlineCss($content, $file)
    {
        if (preg_match_all('/style\s*=\s*["\']([^"\']*)["\']/', $content, $matches)) {
            $cssContent = '';
            foreach ($matches[1] as $css) {
                $cssContent .= $css . "\n";
            }
            
            // Create CSS file
            $cssFile = $this->getCssFilePath($file);
            if (!is_dir(dirname($cssFile))) {
                mkdir(dirname($cssFile), 0755, true);
            }
            file_put_contents($cssFile, $cssContent);
            
            // Remove inline styles
            $content = preg_replace('/style\s*=\s*["\'][^"\']*["\']/', '', $content);
        }
        
        return $content;
    }

    /**
     * Extract inline JavaScript to external file
     */
    private function extractInlineJs($content, $file)
    {
        if (preg_match_all('/<script[^>]*>([\s\S]*?)<\/script>/', $content, $matches)) {
            $jsContent = '';
            foreach ($matches[1] as $js) {
                $jsContent .= $js . "\n";
            }
            
            // Create JS file
            $jsFile = $this->getJsFilePath($file);
            if (!is_dir(dirname($jsFile))) {
                mkdir(dirname($jsFile), 0755, true);
            }
            file_put_contents($jsFile, $jsContent);
            
            // Remove inline scripts
            $content = preg_replace('/<script[^>]*>[\s\S]*?<\/script>/', '', $content);
        }
        
        return $content;
    }

    /**
     * Remove @push directives
     */
    private function removePushDirectives($content)
    {
        return preg_replace('/@push\s*\([\'"](styles|scripts)[\'"][\s\S]*?@endpush/', '', $content);
    }

    /**
     * Remove @php blocks
     */
    private function removePhpBlocks($content)
    {
        return preg_replace('/@php[\s\S]*?@endphp/', '', $content);
    }

    /**
     * Fix hardcoded text
     */
    private function fixHardcodedText($content)
    {
        // This is a simplified example - in practice, you'd need more sophisticated text detection
        $content = preg_replace('/>([A-Za-z][^<]*?)</', '>{{ __(\'key\') }}<', $content);
        return $content;
    }

    /**
     * Fix SVG icons
     */
    private function fixSvgIcons($content)
    {
        return preg_replace('/<svg[\s\S]*?<\/svg>/', '<i class="fas fa-icon"></i>', $content);
    }

    /**
     * Remove success logging
     */
    private function removeSuccessLogging($content)
    {
        return preg_replace('/Log::info\s*\([^)]*success[^)]*\)|Log::info\s*\([^)]*completed[^)]*\)|Log::info\s*\([^)]*created[^)]*\)|Log::info\s*\([^)]*updated[^)]*\)|Log::info\s*\([^)]*deleted[^)]*\)/i', '', $content);
    }

    /**
     * Remove unused imports
     */
    private function removeUnusedImports($content)
    {
        if (preg_match_all('/^use\s+([^;]+);/m', $content, $matches)) {
            foreach ($matches[1] as $import) {
                $className = basename(trim($import));
                if (!preg_match('/\b' . preg_quote($className, '/') . '\b/', $content)) {
                    $content = preg_replace('/^use\s+' . preg_quote($import, '/') . ';/m', '', $content);
                }
            }
        }
        return $content;
    }

    /**
     * Consolidate duplicate code
     */
    private function consolidateDuplicateCode($content)
    {
        // This is a simplified example - in practice, you'd need more sophisticated duplicate detection
        return $content;
    }

    /**
     * Fix PHPDoc issues
     */
    private function fixPhpDocIssues($content)
    {
        // Remove @version, @since, @author from method-level PHPDoc
        $content = preg_replace('/\/\*\*[\s\S]*?@(version|since|author)[\s\S]*?\*\/\s*(?!class|interface|trait)/', '', $content);
        return $content;
    }

    /**
     * Remove duplicate CSS rules
     */
    private function removeDuplicateCssRules($content)
    {
        $rules = [];
        $lines = explode("\n", $content);
        $newLines = [];
        
        foreach ($lines as $line) {
            if (preg_match('/\.([a-zA-Z0-9_-]+)\s*\{/', $line, $matches)) {
                $rule = $matches[1];
                if (isset($rules[$rule])) {
                    continue; // Skip duplicate rule
                }
                $rules[$rule] = true;
            }
            $newLines[] = $line;
        }
        
        return implode("\n", $newLines);
    }

    /**
     * Remove duplicate functions
     */
    private function removeDuplicateFunctions($content)
    {
        $functions = [];
        $lines = explode("\n", $content);
        $newLines = [];
        $inFunction = false;
        $currentFunction = '';
        
        foreach ($lines as $line) {
            if (preg_match('/function\s+(\w+)\s*\(/', $line, $matches)) {
                $func = $matches[1];
                if (isset($functions[$func])) {
                    $inFunction = true;
                    $currentFunction = $func;
                    continue; // Skip duplicate function
                }
                $functions[$func] = true;
                $inFunction = true;
                $currentFunction = $func;
            }
            
            if ($inFunction && $line === '}') {
                $inFunction = false;
                $currentFunction = '';
                continue;
            }
            
            if (!$inFunction) {
                $newLines[] = $line;
            }
        }
        
        return implode("\n", $newLines);
    }

    /**
     * Remove HTML from language files
     */
    private function removeHtmlFromLangFiles($content)
    {
        return preg_replace('/<[^>]+>/', '', $content);
    }

    /**
     * Get CSS file path
     */
    private function getCssFilePath($bladeFile)
    {
        $relativePath = str_replace($this->projectRoot . '/resources/views/', '', $bladeFile);
        $relativePath = str_replace('.blade.php', '', $relativePath);
        return $this->projectRoot . '/public/assets/css/' . $relativePath . '.css';
    }

    /**
     * Get JavaScript file path
     */
    private function getJsFilePath($bladeFile)
    {
        $relativePath = str_replace($this->projectRoot . '/resources/views/', '', $bladeFile);
        $relativePath = str_replace('.blade.php', '', $relativePath);
        return $this->projectRoot . '/public/assets/js/' . $relativePath . '.js';
    }

    /**
     * Backup file
     */
    private function backupFile($file)
    {
        $relativePath = str_replace($this->projectRoot . '/', '', $file);
        $backupFile = $this->backupDir . '/' . $relativePath;
        $backupDir = dirname($backupFile);
        
        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }
        
        copy($file, $backupFile);
    }

    /**
     * Get Blade files
     */
    private function getBladeFiles()
    {
        return $this->getFilesByExtension(['.blade.php'], 'resources/views');
    }

    /**
     * Get PHP files
     */
    private function getPhpFiles()
    {
        return $this->getFilesByExtension(['.php'], 'app');
    }

    /**
     * Get CSS files
     */
    private function getCssFiles()
    {
        return $this->getFilesByExtension(['.css', '.scss'], 'public/assets');
    }

    /**
     * Get JavaScript files
     */
    private function getJsFiles()
    {
        return $this->getFilesByExtension(['.js'], 'public/assets');
    }

    /**
     * Get language files
     */
    private function getLanguageFiles()
    {
        return $this->getFilesByExtension(['.php'], 'resources/lang');
    }

    /**
     * Get files by extension
     */
    private function getFilesByExtension($extensions, $directory = null)
    {
        $directory = $directory ?: $this->projectRoot;
        $files = [];
        
        if (!is_dir($directory)) {
            return $files;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $extension = '.' . $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $files[] = $file->getPathname();
                }
            }
        }
        
        return $files;
    }

    /**
     * Generate fix report
     */
    private function generateFixReport()
    {
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "🔧 AUTO-FIX REPORT\n";
        echo str_repeat("=", 60) . "\n\n";
        
        echo "✅ Fixes Applied: {$this->fixesApplied}\n";
        echo "📁 Backup Location: {$this->backupDir}\n\n";
        
        echo "🎯 NEXT STEPS:\n";
        echo "• Review all changes before committing\n";
        echo "• Test functionality after fixes\n";
        echo "• Run tests to ensure nothing is broken\n";
        echo "• Commit changes if everything looks good\n\n";
        
        echo "✅ Auto-fix completed successfully!\n";
    }
}

// Run the auto-fix
$fix = new EnvatoAutoFix();
$fix->runAutoFix();
