<?php

return [
    'previous' => '&laquo; पिछला',
    'next' => 'अगला &raquo;',

];
