<?php

/**
 * Security Scanner for PHP Files
 * كاشف الأمان لملفات PHP.
 *
 * This script scans PHP files for common security vulnerabilities:
 * - SQL Injection vulnerabilities
 * - XSS (Cross-Site Scripting) vulnerabilities
 * - Input validation issues
 * - File inclusion vulnerabilities
 * - Command injection vulnerabilities
 */
class SecurityScanner
{
    private $scanResults = [];

    private $vulnerabilityCount = 0;

    private $scannedFiles = 0;

    private $startTime;

    // Patterns for different vulnerability types
    private $patterns = [
        'sql_injection' => [
            'direct_queries' => [
                '/\$[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/DB::raw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->whereRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->selectRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->orderByRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->havingRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->groupByRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
            ],
            'concatenation' => [
                '/\$[a-zA-Z_][a-zA-Z0-9_]*\s*\.\s*\$[a-zA-Z_][a-zA-Z0-9_]*/',
                '/["\']\s*\.\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\.\s*["\']/',
            ],
            'direct_sql' => [
                '/mysql_query\s*\(/',
                '/mysqli_query\s*\(/',
                '/pg_query\s*\(/',
                '/sqlite_query\s*\(/',
            ],
        ],

        'xss_vulnerabilities' => [
            'echo_without_escape' => [
                '/echo\s+[^;]*\$[a-zA-Z_][a-zA-Z0-9_]*[^;]*;/',
                '/print\s+[^;]*\$[a-zA-Z_][a-zA-Z0-9_]*[^;]*;/',
                '/<\?=\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\?>/',
            ],
            'html_output' => [
                '/->html\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/{!!\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*!!}/',
                '/@html\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
            ],
            'javascript_injection' => [
                '/<script[^>]*>.*\$[a-zA-Z_][a-zA-Z0-9_]*.*<\/script>/',
                '/onclick\s*=\s*["\'][^"\']*\$[a-zA-Z_][a-zA-Z0-9_]*[^"\']*["\']/',
                '/onload\s*=\s*["\'][^"\']*\$[a-zA-Z_][a-zA-Z0-9_]*[^"\']*["\']/',
            ],
        ],

        'input_validation' => [
            'missing_validation' => [
                '/\$_[GET|POST|REQUEST|COOKIE]\[[^\]]+\]\s*(?!.*->validate|.*->rules|.*Validator::make)/',
                '/request\([^)]+\)(?!.*->validate|.*->rules)/',
                '/Input::get\([^)]+\)(?!.*->validate|.*->rules)/',
            ],
            'direct_usage' => [
                '/\$_[GET|POST|REQUEST|COOKIE]\[[^\]]+\]\s*[^=]*=/',
                '/request\([^)]+\)\s*[^=]*=/',
            ],
        ],

        'file_inclusion' => [
            'include_variables' => [
                '/include\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/require\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/include_once\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/require_once\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
            ],
            'path_traversal' => [
                '/\.\.\//',
                '/\.\.\\\\/',
            ],
        ],

        'command_injection' => [
            'system_calls' => [
                '/system\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/exec\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/shell_exec\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/passthru\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/`[^`]*\$[a-zA-Z_][a-zA-Z0-9_]*[^`]*`/',
            ],
        ],

        'sensitive_data' => [
            'hardcoded_secrets' => [
                '/["\'][a-zA-Z0-9+/]{40,}["\']/', // Base64 encoded secrets
                '/["\'][a-f0-9]{32,}["\']/', // MD5/SHA hashes
                '/password\s*=\s*["\'][^"\']+["\']/',
                '/secret\s*=\s*["\'][^"\']+["\']/',
                '/api_key\s*=\s*["\'][^"\']+["\']/',
            ],
        ],
    ];

    public function __construct()
    {
        $this->startTime = microtime(true);
        echo "🔍 بدء فحص الأمان للملفات...\n";
        echo "================================\n\n";
    }

    /**
     * Scan a single file for vulnerabilities.
     */
    public function scanFile($filePath)
    {
        if (! file_exists($filePath) || ! is_readable($filePath)) {
            return false;
        }

        $content = file_get_contents($filePath);
        $lines = explode("\n", $content);
        $fileResults = [];

        foreach ($this->patterns as $category => $patterns) {
            foreach ($patterns as $type => $patternList) {
                foreach ($patternList as $pattern) {
                    if (preg_match_all($pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
                        foreach ($matches[0] as $match) {
                            $lineNumber = substr_count(substr($content, 0, $match[1]), "\n") + 1;
                            $lineContent = isset($lines[$lineNumber - 1]) ? trim($lines[$lineNumber - 1]) : '';

                            $fileResults[] = [
                                'category' => $category,
                                'type' => $type,
                                'line' => $lineNumber,
                                'content' => $lineContent,
                                'match' => $match[0],
                                'severity' => $this->getSeverity($category, $type),
                            ];

                            $this->vulnerabilityCount++;
                        }
                    }
                }
            }
        }

        if (! empty($fileResults)) {
            $this->scanResults[$filePath] = $fileResults;
        }

        $this->scannedFiles++;

        return true;
    }

    /**
     * Scan directory recursively.
     */
    public function scanDirectory($directory, $extensions = ['php'])
    {
        if (! is_dir($directory)) {
            echo "❌ المجلد غير موجود: $directory\n";

            return false;
        }

        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'node_modules', '.git', 'storage', 'bootstrap/cache'];

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
        );

        foreach ($iterator as $file) {
            if ($file->isFile() && in_array($file->getExtension(), $extensions)) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($directory.DIRECTORY_SEPARATOR, '', $filePath);

                // Check if file is in excluded directory
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir.DIRECTORY_SEPARATOR) === 0 ||
                        strpos($relativePath, $excludeDir.'/') === 0 ||
                        $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }

                if (! $shouldExclude) {
                    $this->scanFile($filePath);
                }
            }
        }

        return true;
    }

    /**
     * Get severity level for vulnerability.
     */
    private function getSeverity($category, $type)
    {
        $highSeverity = [
            'sql_injection' => ['direct_queries', 'direct_sql'],
            'command_injection' => ['system_calls'],
            'file_inclusion' => ['include_variables'],
        ];

        $mediumSeverity = [
            'xss_vulnerabilities' => ['echo_without_escape', 'html_output'],
            'input_validation' => ['missing_validation', 'direct_usage'],
        ];

        if (isset($highSeverity[$category]) && in_array($type, $highSeverity[$category])) {
            return 'HIGH';
        } elseif (isset($mediumSeverity[$category]) && in_array($type, $mediumSeverity[$category])) {
            return 'MEDIUM';
        }

        return 'LOW';
    }

    /**
     * Generate detailed report.
     */
    public function generateReport()
    {
        $endTime = microtime(true);
        $executionTime = round($endTime - $this->startTime, 2);

        echo "\n".str_repeat('=', 60)."\n";
        echo "📊 تقرير فحص الأمان\n";
        echo str_repeat('=', 60)."\n";
        echo "الملفات المفحوصة: {$this->scannedFiles}\n";
        echo "إجمالي الثغرات: {$this->vulnerabilityCount}\n";
        echo "وقت التنفيذ: {$executionTime} ثانية\n\n";

        if (empty($this->scanResults)) {
            echo "✅ لم يتم العثور على ثغرات أمنية!\n";

            return;
        }

        // Group by severity
        $severityGroups = ['HIGH' => [], 'MEDIUM' => [], 'LOW' => []];

        foreach ($this->scanResults as $file => $vulnerabilities) {
            foreach ($vulnerabilities as $vuln) {
                $severityGroups[$vuln['severity']][] = [
                    'file' => $file,
                    'vulnerability' => $vuln,
                ];
            }
        }

        // Display by severity
        foreach (['HIGH', 'MEDIUM', 'LOW'] as $severity) {
            if (! empty($severityGroups[$severity])) {
                $color = $severity === 'HIGH' ? '🔴' : ($severity === 'MEDIUM' ? '🟡' : '🟢');
                echo "{$color} مستوى الخطر: {$severity} (".count($severityGroups[$severity])." ثغرة)\n";
                echo str_repeat('-', 40)."\n";

                foreach ($severityGroups[$severity] as $item) {
                    $this->displayVulnerability($item['file'], $item['vulnerability']);
                }
                echo "\n";
            }
        }

        // Summary by category
        $this->displayCategorySummary();

        // Recommendations
        $this->displayRecommendations();
    }

    /**
     * Display individual vulnerability.
     */
    private function displayVulnerability($file, $vuln)
    {
        $relativePath = str_replace(getcwd().DIRECTORY_SEPARATOR, '', $file);
        echo "📁 الملف: {$relativePath}\n";
        echo "📍 السطر: {$vuln['line']}\n";
        echo '🔍 النوع: '.$this->getCategoryName($vuln['category']).' - '.$this->getTypeName($vuln['type'])."\n";
        echo "💻 الكود: {$vuln['content']}\n";
        echo "🎯 المطابقة: {$vuln['match']}\n\n";
    }

    /**
     * Display category summary.
     */
    private function displayCategorySummary()
    {
        $categoryCount = [];
        foreach ($this->scanResults as $file => $vulnerabilities) {
            foreach ($vulnerabilities as $vuln) {
                $category = $vuln['category'];
                $categoryCount[$category] = ($categoryCount[$category] ?? 0) + 1;
            }
        }

        echo "📈 ملخص الثغرات حسب الفئة:\n";
        echo str_repeat('-', 30)."\n";
        foreach ($categoryCount as $category => $count) {
            echo '• '.$this->getCategoryName($category).": {$count}\n";
        }
        echo "\n";
    }

    /**
     * Display security recommendations.
     */
    private function displayRecommendations()
    {
        echo "💡 التوصيات الأمنية:\n";
        echo str_repeat('-', 30)."\n";
        echo "1. استخدم Prepared Statements لجميع استعلامات قاعدة البيانات\n";
        echo "2. استخدم Laravel's built-in validation للتحقق من المدخلات\n";
        echo "3. استخدم {{ }} بدلاً من {!! !!} في Blade templates\n";
        echo "4. تجنب استخدام متغيرات في include/require\n";
        echo "5. استخدم Laravel's built-in methods بدلاً من system calls\n";
        echo "6. لا تخزن كلمات المرور أو المفاتيح السرية في الكود\n";
        echo "7. استخدم Laravel's CSRF protection\n";
        echo "8. قم بتفعيل Laravel's security middleware\n\n";
    }

    /**
     * Get category name in Arabic.
     */
    private function getCategoryName($category)
    {
        $names = [
            'sql_injection' => 'حقن SQL',
            'xss_vulnerabilities' => 'ثغرات XSS',
            'input_validation' => 'التحقق من المدخلات',
            'file_inclusion' => 'تضمين الملفات',
            'command_injection' => 'حقن الأوامر',
            'sensitive_data' => 'البيانات الحساسة',
        ];

        return $names[$category] ?? $category;
    }

    /**
     * Get type name in Arabic.
     */
    private function getTypeName($type)
    {
        $names = [
            'direct_queries' => 'استعلامات مباشرة',
            'concatenation' => 'ربط النصوص',
            'direct_sql' => 'SQL مباشر',
            'echo_without_escape' => 'إخراج بدون حماية',
            'html_output' => 'إخراج HTML',
            'javascript_injection' => 'حقن JavaScript',
            'missing_validation' => 'عدم التحقق',
            'direct_usage' => 'استخدام مباشر',
            'include_variables' => 'تضمين متغيرات',
            'path_traversal' => 'عبور المسارات',
            'system_calls' => 'استدعاءات النظام',
            'hardcoded_secrets' => 'أسرار مكتوبة في الكود',
        ];

        return $names[$type] ?? $type;
    }

    /**
     * Save report to file.
     */
    public function saveReport($filename = 'security_report.txt')
    {
        ob_start();
        $this->generateReport();
        $report = ob_get_clean();

        file_put_contents($filename, $report);
        echo "📄 تم حفظ التقرير في: {$filename}\n";
    }
}

// Main execution
if (php_sapi_name() === 'cli') {
    $scanner = new SecurityScanner();

    // Get directory to scan (default: current directory)
    $directory = $argv[1] ?? getcwd();

    echo "🔍 فحص المجلد: {$directory}\n\n";

    // Scan the directory
    if ($scanner->scanDirectory($directory)) {
        // Generate and display report
        $scanner->generateReport();

        // Save report to file
        $scanner->saveReport('security_report_'.date('Y-m-d_H-i-s').'.txt');
    } else {
        echo "❌ فشل في فحص المجلد\n";
    }
} else {
    echo "هذا السكريبت يجب تشغيله من سطر الأوامر (CLI)\n";
    echo "استخدام: php security_scanner.php [مسار_المجلد]\n";
}
