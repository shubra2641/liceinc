<?php
/**
 * Security Files Analyzer
 * محلل ملفات الأمان - يحدد الملفات التي تحتاج إصلاح يدوي
 * 
 * This script analyzes PHP files and identifies files with real security vulnerabilities
 * that require manual fixing, excluding false positives.
 */

class SecurityFilesAnalyzer
{
    private $vulnerableFiles = [];
    private $scanResults = [];
    private $startTime;
    
    // Real security vulnerability patterns (excluding false positives)
    private $realVulnerabilities = [
        'hardcoded_secrets' => [
            'patterns' => [
                '/["\'](?:password|secret|key|token|api_key|private_key|access_token)\s*["\']?\s*[:=]\s*["\'][^"\']{20,}["\']/i',
                '/["\'](?:password|secret|key|token|api_key|private_key|access_token)\s*["\']?\s*[:=]\s*["\'][a-zA-Z0-9+/]{40,}["\']/i',
                '/["\'](?:password|secret|key|token|api_key|private_key|access_token)\s*["\']?\s*[:=]\s*["\'][a-f0-9]{32,}["\']/i',
            ],
            'description' => 'أسرار مكتوبة في الكود'
        ],
        
        'xss_vulnerabilities' => [
            'patterns' => [
                '/{!!\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*!!}/',
                '/onclick\s*=\s*["\'][^"\']*\$[a-zA-Z_][a-zA-Z0-9_]*[^"\']*["\']/',
                '/onload\s*=\s*["\'][^"\']*\$[a-zA-Z_][a-zA-Z0-9_]*[^"\']*["\']/',
                '/onerror\s*=\s*["\'][^"\']*\$[a-zA-Z_][a-zA-Z0-9_]*[^"\']*["\']/',
                '/<script[^>]*>.*\$[a-zA-Z_][a-zA-Z0-9_]*.*<\/script>/',
            ],
            'description' => 'ثغرات XSS'
        ],
        
        'sql_injection' => [
            'patterns' => [
                '/DB::raw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->whereRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->selectRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->orderByRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->havingRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
                '/->groupByRaw\s*\(\s*["\'].*\$[a-zA-Z_][a-zA-Z0-9_]*.*["\']/',
            ],
            'description' => 'حقن SQL'
        ],
        
        'command_injection' => [
            'patterns' => [
                '/system\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/exec\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/shell_exec\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/passthru\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/`[^`]*\$[a-zA-Z_][a-zA-Z0-9_]*[^`]*`/',
            ],
            'description' => 'حقن الأوامر'
        ],
        
        'file_inclusion' => [
            'patterns' => [
                '/include\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/require\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/include_once\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
                '/require_once\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)/',
            ],
            'description' => 'تضمين الملفات'
        ],
        
        'input_validation' => [
            'patterns' => [
                '/\$_[GET|POST|REQUEST|COOKIE]\[[^\]]+\]\s*(?!.*->validate|.*->rules|.*Validator::make)/',
                '/request\([^)]+\)(?!.*->validate|.*->rules)/',
                '/Input::get\([^)]+\)(?!.*->validate|.*->rules)/',
            ],
            'description' => 'عدم التحقق من المدخلات'
        ]
    ];
    
    public function __construct()
    {
        $this->startTime = microtime(true);
        echo "🔍 بدء تحليل ملفات الأمان...\n";
        echo "================================\n\n";
    }
    
    /**
     * Scan a single file for real vulnerabilities
     */
    public function scanFile($filePath)
    {
        if (!file_exists($filePath) || !is_readable($filePath)) {
            return false;
        }
        
        $content = file_get_contents($filePath);
        $lines = explode("\n", $content);
        $fileResults = [];
        
        foreach ($this->realVulnerabilities as $category => $vulnData) {
            foreach ($vulnData['patterns'] as $pattern) {
                if (preg_match_all($pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
                    foreach ($matches[0] as $match) {
                        $lineNumber = substr_count(substr($content, 0, $match[1]), "\n") + 1;
                        $lineContent = isset($lines[$lineNumber - 1]) ? trim($lines[$lineNumber - 1]) : '';
                        
                        $fileResults[] = [
                            'category' => $category,
                            'description' => $vulnData['description'],
                            'line' => $lineNumber,
                            'content' => $lineContent,
                            'match' => $match[0],
                            'severity' => $this->getSeverity($category)
                        ];
                    }
                }
            }
        }
        
        if (!empty($fileResults)) {
            $this->scanResults[$filePath] = $fileResults;
            $this->vulnerableFiles[] = $filePath;
        }
        
        return true;
    }
    
    /**
     * Scan directory recursively for real vulnerabilities
     */
    public function scanDirectory($directory, $extensions = ['php'])
    {
        if (!is_dir($directory)) {
            echo "❌ المجلد غير موجود: $directory\n";
            return false;
        }
        
        // Directories to exclude from scanning
        $excludeDirs = ['vendor', 'tests', 'node_modules', '.git', 'storage', 'bootstrap/cache'];
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile() && in_array($file->getExtension(), $extensions)) {
                $filePath = $file->getPathname();
                $relativePath = str_replace($directory . DIRECTORY_SEPARATOR, '', $filePath);
                
                // Check if file is in excluded directory
                $shouldExclude = false;
                foreach ($excludeDirs as $excludeDir) {
                    if (strpos($relativePath, $excludeDir . DIRECTORY_SEPARATOR) === 0 || 
                        strpos($relativePath, $excludeDir . '/') === 0 ||
                        $relativePath === $excludeDir) {
                        $shouldExclude = true;
                        break;
                    }
                }
                
                if (!$shouldExclude) {
                    $this->scanFile($filePath);
                }
            }
        }
        
        return true;
    }
    
    /**
     * Get severity level for vulnerability
     */
    private function getSeverity($category)
    {
        $highSeverity = ['hardcoded_secrets', 'sql_injection', 'command_injection', 'file_inclusion'];
        $mediumSeverity = ['xss_vulnerabilities', 'input_validation'];
        
        if (in_array($category, $highSeverity)) {
            return 'HIGH';
        } elseif (in_array($category, $mediumSeverity)) {
            return 'MEDIUM';
        }
        
        return 'LOW';
    }
    
    /**
     * Generate files list for manual fixing
     */
    public function generateFilesList()
    {
        $endTime = microtime(true);
        $executionTime = round($endTime - $this->startTime, 2);
        
        echo "\n" . str_repeat("=", 60) . "\n";
        echo "📋 قائمة الملفات التي تحتاج إصلاح يدوي\n";
        echo str_repeat("=", 60) . "\n";
        echo "الملفات المكتشفة: " . count($this->vulnerableFiles) . "\n";
        echo "وقت التنفيذ: {$executionTime} ثانية\n\n";
        
        if (empty($this->vulnerableFiles)) {
            echo "✅ لم يتم العثور على ملفات تحتاج إصلاح يدوي!\n";
            return;
        }
        
        // Group by severity
        $severityGroups = ['HIGH' => [], 'MEDIUM' => [], 'LOW' => []];
        
        foreach ($this->scanResults as $file => $vulnerabilities) {
            foreach ($vulnerabilities as $vuln) {
                $severityGroups[$vuln['severity']][] = [
                    'file' => $file,
                    'vulnerability' => $vuln
                ];
            }
        }
        
        // Display files by severity
        foreach (['HIGH', 'MEDIUM', 'LOW'] as $severity) {
            if (!empty($severityGroups[$severity])) {
                $color = $severity === 'HIGH' ? '🔴' : ($severity === 'MEDIUM' ? '🟡' : '🟢');
                echo "{$color} مستوى الخطر: {$severity} (" . count($severityGroups[$severity]) . " ثغرة)\n";
                echo str_repeat("-", 40) . "\n";
                
                $filesInSeverity = [];
                foreach ($severityGroups[$severity] as $item) {
                    $filesInSeverity[$item['file']] = true;
                }
                
                foreach (array_keys($filesInSeverity) as $file) {
                    $relativePath = str_replace(getcwd() . DIRECTORY_SEPARATOR, '', $file);
                    echo "📁 {$relativePath}\n";
                }
                echo "\n";
            }
        }
        
        // Summary by category
        $this->displayCategorySummary();
        
        // Manual fixing instructions
        $this->displayManualFixingInstructions();
    }
    
    /**
     * Display category summary
     */
    private function displayCategorySummary()
    {
        $categoryCount = [];
        foreach ($this->scanResults as $file => $vulnerabilities) {
            foreach ($vulnerabilities as $vuln) {
                $category = $vuln['category'];
                $categoryCount[$category] = ($categoryCount[$category] ?? 0) + 1;
            }
        }
        
        echo "📈 ملخص الثغرات حسب الفئة:\n";
        echo str_repeat("-", 30) . "\n";
        foreach ($categoryCount as $category => $count) {
            echo "• " . $this->getCategoryName($category) . ": {$count}\n";
        }
        echo "\n";
    }
    
    /**
     * Display manual fixing instructions
     */
    private function displayManualFixingInstructions()
    {
        echo "🔧 تعليمات الإصلاح اليدوي:\n";
        echo str_repeat("-", 30) . "\n";
        echo "1. 🔴 ثغرات عالية الخطورة:\n";
        echo "   - أسرار مكتوبة في الكود: انقلها إلى ملف .env\n";
        echo "   - حقن SQL: استخدم Eloquent ORM أو Prepared Statements\n";
        echo "   - حقن الأوامر: تجنب استخدام system(), exec() مع متغيرات\n";
        echo "   - تضمين الملفات: تجنب استخدام متغيرات في include/require\n\n";
        
        echo "2. 🟡 ثغرات متوسطة الخطورة:\n";
        echo "   - ثغرات XSS: استخدم {{ }} بدلاً من {!! !!} أو Purify::clean()\n";
        echo "   - عدم التحقق: أضف validation rules في Request classes\n\n";
        
        echo "3. 🟢 ثغرات منخفضة الخطورة:\n";
        echo "   - راجع الكود للتأكد من الأمان\n\n";
        
        echo "💡 نصائح إضافية:\n";
        echo "- استخدم Laravel's built-in validation\n";
        echo "- استخدم Laravel's CSRF protection\n";
        echo "- استخدم Laravel's security middleware\n";
        echo "- راجع Laravel Security Best Practices\n\n";
    }
    
    /**
     * Get category name in Arabic
     */
    private function getCategoryName($category)
    {
        $names = [
            'hardcoded_secrets' => 'أسرار مكتوبة في الكود',
            'xss_vulnerabilities' => 'ثغرات XSS',
            'sql_injection' => 'حقن SQL',
            'command_injection' => 'حقن الأوامر',
            'file_inclusion' => 'تضمين الملفات',
            'input_validation' => 'عدم التحقق من المدخلات'
        ];
        
        return $names[$category] ?? $category;
    }
    
    /**
     * Save files list to file
     */
    public function saveFilesList($filename = 'security_files_to_fix.txt')
    {
        ob_start();
        $this->generateFilesList();
        $report = ob_get_clean();
        
        file_put_contents($filename, $report);
        echo "📄 تم حفظ قائمة الملفات في: {$filename}\n";
    }
}

// Main execution
if (php_sapi_name() === 'cli') {
    $analyzer = new SecurityFilesAnalyzer();
    
    // Get directory to scan (default: current directory)
    $directory = $argv[1] ?? getcwd();
    
    echo "🔍 فحص المجلد: {$directory}\n\n";
    
    // Scan the directory
    if ($analyzer->scanDirectory($directory)) {
        // Generate and display files list
        $analyzer->generateFilesList();
        
        // Save files list to file
        $analyzer->saveFilesList('security_files_to_fix_' . date('Y-m-d_H-i-s') . '.txt');
    } else {
        echo "❌ فشل في فحص المجلد\n";
    }
} else {
    echo "هذا السكريبت يجب تشغيله من سطر الأوامر (CLI)\n";
    echo "استخدام: php security_files_analyzer.php [مسار_المجلد]\n";
}
?>
