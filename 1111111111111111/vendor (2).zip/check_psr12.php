<?php

/**
 * PSR-12 Compliance Checker.
 *
 * Simple script to check PHP files for PSR-12 compliance
 * Excludes vendor/, tests/, and storage/ directories
 *
 * @author My-Logos Team
 *
 * @version 1.0.0
 */
class check_psr12
{
    private $excludedDirs = ['vendor', 'tests', 'storage', 'resources', 'node_modules'];

    private $issues = [];

    private $checkedFiles = 0;

    private $totalIssues = 0;

    public function __construct()
    {
        echo "🔍 PSR-12 Compliance Checker\n";
        echo "================================\n\n";
    }

    /**
     * Start the checking process.
     */
    public function check()
    {
        $this->scanDirectory('.');
        $this->displayResults();
    }

    /**
     * Scan directory recursively.
     */
    private function scanDirectory($dir)
    {
        $files = scandir($dir);

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $fullPath = $dir.DIRECTORY_SEPARATOR.$file;

            // Skip excluded directories
            if (is_dir($fullPath) && in_array($file, $this->excludedDirs)) {
                echo "⏭️  Skipping: {$fullPath}\n";

                continue;
            }

            if (is_dir($fullPath)) {
                $this->scanDirectory($fullPath);
            } elseif (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
                $this->checkFile($fullPath);
            }
        }
    }

    /**
     * Check individual PHP file.
     */
    private function checkFile($filePath)
    {
        $this->checkedFiles++;
        echo "🔍 Checking: {$filePath}\n";

        $content = file_get_contents($filePath);
        $lines = explode("\n", $content);
        $fileIssues = [];

        foreach ($lines as $lineNumber => $line) {
            $lineNumber++; // 1-based line numbers

            // Check for common PSR-12 violations
            $issues = $this->checkLine($line, $lineNumber);
            if (! empty($issues)) {
                $fileIssues = array_merge($fileIssues, $issues);
            }
        }

        if (! empty($fileIssues)) {
            $this->issues[$filePath] = $fileIssues;
            $this->totalIssues += count($fileIssues);
        }
    }

    /**
     * Check individual line for PSR-12 violations.
     */
    private function checkLine($line, $lineNumber)
    {
        $issues = [];

        // Remove leading/trailing whitespace for checks
        $trimmedLine = trim($line);
        $originalLine = $line;

        // 1. Check for trailing whitespace
        if (preg_match('/\s+$/', $originalLine)) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Trailing Whitespace',
                'message' => 'Remove trailing whitespace',
                'code' => 'PSR-12: No trailing whitespace',
            ];
        }

        // 2. Check for tabs (should use spaces)
        if (strpos($originalLine, "\t") !== false) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Tab Usage',
                'message' => 'Use spaces instead of tabs (4 spaces per indent)',
                'code' => 'PSR-12: Use 4 spaces for indentation',
            ];
        }

        // 3. Check for long lines (over 120 characters)
        if (strlen($originalLine) > 120) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Line Length',
                'message' => 'Line exceeds 120 characters ('.strlen($originalLine).' chars)',
                'code' => 'PSR-12: Lines should not exceed 120 characters',
            ];
        }

        // 4. Check for mixed line endings
        if (strpos($originalLine, "\r\n") !== false) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Line Endings',
                'message' => 'Use LF line endings, not CRLF',
                'code' => 'PSR-12: Use LF line endings',
            ];
        }

        // 5. Check for multiple consecutive blank lines
        if (empty($trimmedLine) && $lineNumber > 1) {
            // This is a simplified check - in practice, you'd need to track consecutive empty lines
        }

        // 6. Check for space before semicolon
        if (preg_match('/\s+;$/', $trimmedLine)) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Spacing',
                'message' => 'Remove space before semicolon',
                'code' => 'PSR-12: No space before semicolon',
            ];
        }

        // 7. Check for missing space after comma
        if (preg_match('/,[^ ]/', $trimmedLine)) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Spacing',
                'message' => 'Add space after comma',
                'code' => 'PSR-12: Add space after comma',
            ];
        }

        // 8. Check for space before opening parenthesis in function calls
        if (preg_match('/\w\s*\(/', $trimmedLine) && ! preg_match('/\w\s*\(/', $trimmedLine)) {
            // This is a complex check that would need more sophisticated parsing
        }

        // 9. Check for proper array formatting
        if (preg_match('/array\s*\(/', $trimmedLine) && ! preg_match('/\[\s*\]/', $trimmedLine)) {
            $issues[] = [
                'line' => $lineNumber,
                'type' => 'Array Syntax',
                'message' => 'Use short array syntax [] instead of array()',
                'code' => 'PSR-12: Use short array syntax',
            ];
        }

        // 10. Check for proper class/method spacing
        if (preg_match('/^class\s+\w+/', $trimmedLine) && $lineNumber > 1) {
            // Check if there's proper spacing before class declaration
        }

        return $issues;
    }

    /**
     * Display results.
     */
    private function displayResults()
    {
        echo "\n".str_repeat('=', 50)."\n";
        echo "📊 RESULTS SUMMARY\n";
        echo str_repeat('=', 50)."\n";
        echo "📁 Files checked: {$this->checkedFiles}\n";
        echo "❌ Total issues: {$this->totalIssues}\n";
        echo '📂 Files with issues: '.count($this->issues)."\n\n";

        if (empty($this->issues)) {
            echo "✅ Congratulations! No PSR-12 violations found.\n";

            return;
        }

        echo "🚨 ISSUES FOUND:\n";
        echo str_repeat('-', 50)."\n\n";

        foreach ($this->issues as $file => $fileIssues) {
            echo "📄 File: {$file}\n";
            echo str_repeat('-', strlen($file) + 7)."\n";

            foreach ($fileIssues as $issue) {
                echo "  Line {$issue['line']}: {$issue['type']}\n";
                echo "  📝 {$issue['message']}\n";
                echo "  📋 {$issue['code']}\n\n";
            }
        }

        echo "\n".str_repeat('=', 50)."\n";
        echo "🔧 MANUAL FIXES REQUIRED\n";
        echo str_repeat('=', 50)."\n";
        echo "This script only detects issues. Manual fixes are required.\n";
        echo "Common fixes:\n";
        echo "• Remove trailing whitespace\n";
        echo "• Replace tabs with 4 spaces\n";
        echo "• Break long lines (120+ characters)\n";
        echo "• Use LF line endings\n";
        echo "• Use short array syntax []\n";
        echo "• Add proper spacing around operators\n";
        echo "• Follow PSR-12 class/method formatting\n\n";
    }
}

// Run the checker
if (php_sapi_name() === 'cli') {
    $checker = new check_psr12();
    $checker->check();
} else {
    echo "This script must be run from the command line.\n";
    echo "Usage: php check_psr12.php\n";
}
