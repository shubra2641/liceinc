<button {{ $attributes->merge(['type' => 'button', 'class' => 'btn-component-secondary']) }}>
    {{ $slot }}
</button>
