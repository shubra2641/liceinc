<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Convert all snake_case column names to camelCase to match the updated codebase.
     * This migration handles all tables and their column name conversions.
     */
    public function up(): void
    {
        // Users table
        $this->renameColumns('users', [
            'email_verified_at' => 'emailVerifiedAt',
            'is_admin' => 'isAdmin',
            'envato_username' => 'envatoUsername',
            'envato_id' => 'envatoId',
            'envato_token' => 'envatoToken',
            'envato_refresh_token' => 'envatoRefreshToken',
            'envato_token_expires_at' => 'envatoTokenExpiresAt',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Products table
        $this->renameColumns('products', [
            'kb_categories' => 'kbCategories',
            'kb_access_required' => 'kbAccessRequired',
            'extended_support_price' => 'extendedSupportPrice',
            'renewal_period_label' => 'renewalPeriodLabel',
            'tax_rate' => 'taxRate',
            'tax_amount' => 'taxAmount',
            'envato_item_id' => 'envatoItemId',
            'is_downloadable' => 'isDownloadable',
            'description_has_html' => 'descriptionHasHtml',
            'requirements_has_html' => 'requirementsHasHtml',
            'installation_guide_has_html' => 'installationGuideHasHtml',
            'installation_guide' => 'installationGuide',
            'category_id' => 'categoryId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Licenses table
        $this->renameColumns('licenses', [
            'purchase_code' => 'purchaseCode',
            'supported_until' => 'supportedUntil',
            'support_expires_at' => 'supportExpiresAt',
            'active_domains_count' => 'activeDomainsCount',
            'envato_item_id' => 'envatoItemId',
            'user_id' => 'userId',
            'product_id' => 'productId',
            'license_expires_at' => 'licenseExpiresAt',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Invoices table
        $this->renameColumns('invoices', [
            'invoice_number' => 'invoiceNumber',
            'due_date' => 'dueDate',
            'user_id' => 'userId',
            'license_id' => 'licenseId',
            'product_id' => 'productId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Tickets table
        $this->renameColumns('tickets', [
            'user_id' => 'userId',
            'license_id' => 'licenseId',
            'product_id' => 'productId',
            'ticket_category_id' => 'ticketCategoryId',
            'requires_login' => 'requiresLogin',
            'requires_valid_purchase_code' => 'requiresValidPurchaseCode',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Product files table
        $this->renameColumns('product_files', [
            'file_size' => 'fileSize',
            'encryption_key' => 'encryptionKey',
            'is_downloadable' => 'isDownloadable',
            'product_id' => 'productId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Product updates table
        $this->renameColumns('product_updates', [
            'file_size' => 'fileSize',
            'is_update' => 'isUpdate',
            'update_info' => 'updateInfo',
            'update_file_path' => 'updateFilePath',
            'download_url' => 'downloadUrl',
            'product_id' => 'productId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Product categories table
        $this->renameColumns('product_categories', [
            'parent_id' => 'parentId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // KB categories table
        $this->renameColumns('kb_categories', [
            'product_id' => 'productId',
            'requires_serial' => 'requiresSerial',
            'requires_purchase_code' => 'requiresPurchaseCode',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // KB articles table
        $this->renameColumns('kb_articles', [
            'kb_category_id' => 'kbCategoryId',
            'product_id' => 'productId',
            'requires_serial' => 'requiresSerial',
            'serial_message' => 'serialMessage',
            'search_type' => 'searchType',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // License logs table
        $this->renameColumns('license_logs', [
            'license_id' => 'licenseId',
            'user_id' => 'userId',
            'request_data' => 'requestData',
            'response_data' => 'responseData',
            'user_agent' => 'userAgent',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // License verification logs table
        $this->renameColumns('license_verification_logs', [
            'license_id' => 'licenseId',
            'user_id' => 'userId',
            'ip_address' => 'ipAddress',
            'user_agent' => 'userAgent',
            'request_data' => 'requestData',
            'response_data' => 'responseData',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Email templates table
        $this->renameColumns('email_templates', [
            'template_type' => 'templateType',
            'template_category' => 'templateCategory',
            'is_active' => 'isActive',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Ticket categories table
        $this->renameColumns('ticket_categories', [
            'template_subject' => 'templateSubject',
            'template_content' => 'templateContent',
            'is_active' => 'isActive',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Programming languages table
        $this->renameColumns('programming_languages', [
            'license_template' => 'licenseTemplate',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Payment settings table
        $this->renameColumns('payment_settings', [
            'is_enabled' => 'isEnabled',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Webhook logs table
        $this->renameColumns('webhook_logs', [
            'webhook_id' => 'webhookId',
            'request_data' => 'requestData',
            'response_data' => 'responseData',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Webhooks table
        $this->renameColumns('webhooks', [
            'is_active' => 'isActive',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // Update notifications table
        $this->renameColumns('update_notifications', [
            'is_read' => 'isRead',
            'is_dismissed' => 'isDismissed',
            'user_id' => 'userId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // System settings table
        $this->renameColumns('system_settings', [
            'setting_key' => 'settingKey',
            'setting_value' => 'settingValue',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);

        // License status table
        $this->renameColumns('license_status', [
            'license_max_attempts' => 'licenseMaxAttempts',
            'license_lockout_minutes' => 'licenseLockoutMinutes',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * Convert all camelCase column names back to snake_case.
     */
    public function down(): void
    {
        // Users table
        $this->renameColumns('users', [
            'emailVerifiedAt' => 'email_verified_at',
            'isAdmin' => 'is_admin',
            'envatoUsername' => 'envato_username',
            'envatoId' => 'envato_id',
            'envatoToken' => 'envato_token',
            'envatoRefreshToken' => 'envato_refresh_token',
            'envatoTokenExpiresAt' => 'envato_token_expires_at',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Products table
        $this->renameColumns('products', [
            'kbCategories' => 'kb_categories',
            'kbAccessRequired' => 'kb_access_required',
            'extendedSupportPrice' => 'extended_support_price',
            'renewalPeriodLabel' => 'renewal_period_label',
            'taxRate' => 'tax_rate',
            'taxAmount' => 'tax_amount',
            'envatoItemId' => 'envato_item_id',
            'isDownloadable' => 'is_downloadable',
            'descriptionHasHtml' => 'description_has_html',
            'requirementsHasHtml' => 'requirements_has_html',
            'installationGuideHasHtml' => 'installation_guide_has_html',
            'installationGuide' => 'installation_guide',
            'categoryId' => 'category_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Licenses table
        $this->renameColumns('licenses', [
            'purchaseCode' => 'purchase_code',
            'supportedUntil' => 'supported_until',
            'supportExpiresAt' => 'support_expires_at',
            'activeDomainsCount' => 'active_domains_count',
            'envatoItemId' => 'envato_item_id',
            'userId' => 'user_id',
            'productId' => 'product_id',
            'licenseExpiresAt' => 'license_expires_at',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Invoices table
        $this->renameColumns('invoices', [
            'invoiceNumber' => 'invoice_number',
            'dueDate' => 'due_date',
            'userId' => 'user_id',
            'licenseId' => 'license_id',
            'productId' => 'product_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Tickets table
        $this->renameColumns('tickets', [
            'userId' => 'user_id',
            'licenseId' => 'license_id',
            'productId' => 'product_id',
            'ticketCategoryId' => 'ticket_category_id',
            'requiresLogin' => 'requires_login',
            'requiresValidPurchaseCode' => 'requires_valid_purchase_code',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Product files table
        $this->renameColumns('product_files', [
            'fileSize' => 'file_size',
            'encryptionKey' => 'encryption_key',
            'isDownloadable' => 'is_downloadable',
            'productId' => 'product_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Product updates table
        $this->renameColumns('product_updates', [
            'fileSize' => 'file_size',
            'isUpdate' => 'is_update',
            'updateInfo' => 'update_info',
            'updateFilePath' => 'update_file_path',
            'downloadUrl' => 'download_url',
            'productId' => 'product_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Product categories table
        $this->renameColumns('product_categories', [
            'parentId' => 'parent_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // KB categories table
        $this->renameColumns('kb_categories', [
            'productId' => 'product_id',
            'requiresSerial' => 'requires_serial',
            'requiresPurchaseCode' => 'requires_purchase_code',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // KB articles table
        $this->renameColumns('kb_articles', [
            'kbCategoryId' => 'kb_category_id',
            'productId' => 'product_id',
            'requiresSerial' => 'requires_serial',
            'serialMessage' => 'serial_message',
            'searchType' => 'search_type',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // License logs table
        $this->renameColumns('license_logs', [
            'licenseId' => 'license_id',
            'userId' => 'user_id',
            'requestData' => 'request_data',
            'responseData' => 'response_data',
            'userAgent' => 'user_agent',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // License verification logs table
        $this->renameColumns('license_verification_logs', [
            'licenseId' => 'license_id',
            'userId' => 'user_id',
            'ipAddress' => 'ip_address',
            'userAgent' => 'user_agent',
            'requestData' => 'request_data',
            'responseData' => 'response_data',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Email templates table
        $this->renameColumns('email_templates', [
            'templateType' => 'template_type',
            'templateCategory' => 'template_category',
            'isActive' => 'is_active',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Ticket categories table
        $this->renameColumns('ticket_categories', [
            'templateSubject' => 'template_subject',
            'templateContent' => 'template_content',
            'isActive' => 'is_active',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Programming languages table
        $this->renameColumns('programming_languages', [
            'licenseTemplate' => 'license_template',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Payment settings table
        $this->renameColumns('payment_settings', [
            'isEnabled' => 'is_enabled',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Webhook logs table
        $this->renameColumns('webhook_logs', [
            'webhookId' => 'webhook_id',
            'requestData' => 'request_data',
            'responseData' => 'response_data',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Webhooks table
        $this->renameColumns('webhooks', [
            'isActive' => 'is_active',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // Update notifications table
        $this->renameColumns('update_notifications', [
            'isRead' => 'is_read',
            'isDismissed' => 'is_dismissed',
            'userId' => 'user_id',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // System settings table
        $this->renameColumns('system_settings', [
            'settingKey' => 'setting_key',
            'settingValue' => 'setting_value',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);

        // License status table
        $this->renameColumns('license_status', [
            'licenseMaxAttempts' => 'license_max_attempts',
            'licenseLockoutMinutes' => 'license_lockout_minutes',
            'createdAt' => 'created_at',
            'updatedAt' => 'updated_at',
        ]);
    }

    /**
     * Helper method to rename columns in a table.
     *
     * @param string $tableName
     * @param array<string, string> $columnMappings
     */
    private function renameColumns(string $tableName, array $columnMappings): void
    {
        if (!Schema::hasTable($tableName)) {
            return;
        }

        foreach ($columnMappings as $oldName => $newName) {
            if (Schema::hasColumn($tableName, $oldName)) {
                Schema::table($tableName, function (Blueprint $table) use ($oldName, $newName) {
                    $table->renameColumn($oldName, $newName);
                });
            }
        }
    }
};