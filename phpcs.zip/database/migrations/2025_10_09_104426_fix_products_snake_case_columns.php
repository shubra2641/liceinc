<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Rename snake_case columns to camelCase
            if (Schema::hasColumn('products', 'purchase_url_envato')) {
                $table->renameColumn('purchase_url_envato', 'purchaseUrlEnvato');
            }
            if (Schema::hasColumn('products', 'purchase_url_buy')) {
                $table->renameColumn('purchase_url_buy', 'purchaseUrlBuy');
            }
            if (Schema::hasColumn('products', 'license_type')) {
                $table->renameColumn('license_type', 'licenseType');
            }
            if (Schema::hasColumn('products', 'supported_until')) {
                $table->renameColumn('supported_until', 'supportedUntil');
            }
            if (Schema::hasColumn('products', 'extended_support_days')) {
                $table->renameColumn('extended_support_days', 'extendedSupportDays');
            }
            if (Schema::hasColumn('products', 'extended_supported_until')) {
                $table->renameColumn('extended_supported_until', 'extendedSupportedUntil');
            }
            if (Schema::hasColumn('products', 'kb_articles')) {
                $table->renameColumn('kb_articles', 'kbArticles');
            }
            if (Schema::hasColumn('products', 'kb_access_message')) {
                $table->renameColumn('kb_access_message', 'kbAccessMessage');
            }
            if (Schema::hasColumn('products', 'integration_file_path')) {
                $table->renameColumn('integration_file_path', 'integrationFilePath');
            }
            if (Schema::hasColumn('products', 'requires_domain')) {
                $table->renameColumn('requires_domain', 'requiresDomain');
            }
            if (Schema::hasColumn('products', 'meta_title')) {
                $table->renameColumn('meta_title', 'metaTitle');
            }
            if (Schema::hasColumn('products', 'meta_description')) {
                $table->renameColumn('meta_description', 'metaDescription');
            }
            if (Schema::hasColumn('products', 'gallery_images')) {
                $table->renameColumn('gallery_images', 'galleryImages');
            }
            if (Schema::hasColumn('products', 'duration_days')) {
                $table->renameColumn('duration_days', 'durationDays');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            // Rename camelCase columns back to snake_case
            if (Schema::hasColumn('products', 'purchaseUrlEnvato')) {
                $table->renameColumn('purchaseUrlEnvato', 'purchase_url_envato');
            }
            if (Schema::hasColumn('products', 'purchaseUrlBuy')) {
                $table->renameColumn('purchaseUrlBuy', 'purchase_url_buy');
            }
            if (Schema::hasColumn('products', 'licenseType')) {
                $table->renameColumn('licenseType', 'license_type');
            }
            if (Schema::hasColumn('products', 'supportedUntil')) {
                $table->renameColumn('supportedUntil', 'supported_until');
            }
            if (Schema::hasColumn('products', 'extendedSupportDays')) {
                $table->renameColumn('extendedSupportDays', 'extended_support_days');
            }
            if (Schema::hasColumn('products', 'extendedSupportedUntil')) {
                $table->renameColumn('extendedSupportedUntil', 'extended_supported_until');
            }
            if (Schema::hasColumn('products', 'kbArticles')) {
                $table->renameColumn('kbArticles', 'kb_articles');
            }
            if (Schema::hasColumn('products', 'kbAccessMessage')) {
                $table->renameColumn('kbAccessMessage', 'kb_access_message');
            }
            if (Schema::hasColumn('products', 'integrationFilePath')) {
                $table->renameColumn('integrationFilePath', 'integration_file_path');
            }
            if (Schema::hasColumn('products', 'requiresDomain')) {
                $table->renameColumn('requiresDomain', 'requires_domain');
            }
            if (Schema::hasColumn('products', 'metaTitle')) {
                $table->renameColumn('metaTitle', 'meta_title');
            }
            if (Schema::hasColumn('products', 'metaDescription')) {
                $table->renameColumn('metaDescription', 'meta_description');
            }
            if (Schema::hasColumn('products', 'galleryImages')) {
                $table->renameColumn('galleryImages', 'gallery_images');
            }
            if (Schema::hasColumn('products', 'durationDays')) {
                $table->renameColumn('durationDays', 'duration_days');
            }
        });
    }
};
