<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Fix camelCase column issues by ensuring all columns are properly renamed.
     * This migration handles any missed column renames from the previous migration.
     */
    public function up(): void
    {
        // Check and fix products table
        $this->fixProductsTable();
        
        // Check and fix other critical tables
        $this->fixUsersTable();
        $this->fixLicensesTable();
        $this->fixInvoicesTable();
        $this->fixTicketsTable();
        $this->fixKbTables();
        $this->fixWebhookTables();
    }

    /**
     * Fix products table columns
     */
    private function fixProductsTable(): void
    {
        if (!Schema::hasTable('products')) {
            return;
        }

        $columnsToRename = [
            'is_active' => 'isActive',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
            'category_id' => 'categoryId',
            'envato_item_id' => 'envatoItemId',
            'is_downloadable' => 'isDownloadable',
            'is_featured' => 'isFeatured',
            'is_popular' => 'isPopular',
            'kb_category_id' => 'kbCategoryId',
            'programming_language' => 'programmingLanguage',
            'renewal_price' => 'renewalPrice',
            'renewal_period' => 'renewalPeriod',
            'support_days' => 'supportDays',
            'tax_rate' => 'taxRate',
            'stock_quantity' => 'stockQuantity',
            'auto_renewal' => 'autoRenewal',
            'renewal_reminder_days' => 'renewalReminderDays',
        ];

        $this->renameColumnsIfExists('products', $columnsToRename);
    }

    /**
     * Fix users table columns
     */
    private function fixUsersTable(): void
    {
        if (!Schema::hasTable('users')) {
            return;
        }

        $columnsToRename = [
            'is_admin' => 'isAdmin',
            'email_verified_at' => 'emailVerifiedAt',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
            'envato_username' => 'envatoUsername',
            'envato_id' => 'envatoId',
            'envato_token' => 'envatoToken',
            'envato_refresh_token' => 'envatoRefreshToken',
            'envato_token_expires_at' => 'envatoTokenExpiresAt',
            'last_login' => 'lastLogin',
            'date_created' => 'dateCreated',
            'email_verified' => 'emailVerified',
            'email_preferences' => 'emailPreferences',
            'pw_reset_key' => 'pwResetKey',
            'pw_reset_expiry' => 'pwResetExpiry',
            'late_fee_override' => 'lateFeeOverride',
            'override_due_notices' => 'overrideDueNotices',
            'separate_invoices' => 'separateInvoices',
            'disable_auto_cc' => 'disableAutoCc',
            'email_opt_out' => 'emailOptOut',
            'marketing_emails_opt_in' => 'marketingEmailsOptIn',
            'override_auto_close' => 'overrideAutoClose',
        ];

        $this->renameColumnsIfExists('users', $columnsToRename);
    }

    /**
     * Fix licenses table columns
     */
    private function fixLicensesTable(): void
    {
        if (!Schema::hasTable('licenses')) {
            return;
        }

        $columnsToRename = [
            'purchase_code' => 'purchaseCode',
            'license_key' => 'licenseKey',
            'license_type' => 'licenseType',
            'max_domains' => 'maxDomains',
            'supported_until' => 'supportedUntil',
            'license_expires_at' => 'licenseExpiresAt',
            'support_expires_at' => 'supportExpiresAt',
            'purchase_date' => 'purchaseDate',
            'user_id' => 'userId',
            'product_id' => 'productId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('licenses', $columnsToRename);
    }

    /**
     * Fix invoices table columns
     */
    private function fixInvoicesTable(): void
    {
        if (!Schema::hasTable('invoices')) {
            return;
        }

        $columnsToRename = [
            'invoice_number' => 'invoiceNumber',
            'order_number' => 'orderNumber',
            'payment_gateway' => 'paymentGateway',
            'user_id' => 'userId',
            'license_id' => 'licenseId',
            'product_id' => 'productId',
            'due_date' => 'dueDate',
            'paid_at' => 'paidAt',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('invoices', $columnsToRename);
    }

    /**
     * Fix tickets table columns
     */
    private function fixTicketsTable(): void
    {
        if (!Schema::hasTable('tickets')) {
            return;
        }

        $columnsToRename = [
            'user_id' => 'userId',
            'license_id' => 'licenseId',
            'product_id' => 'productId',
            'ticket_category_id' => 'ticketCategoryId',
            'purchase_code' => 'purchaseCode',
            'invoice_id' => 'invoiceId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('tickets', $columnsToRename);
    }

    /**
     * Fix KB tables columns
     */
    private function fixKbTables(): void
    {
        // KB Categories
        if (Schema::hasTable('kb_categories')) {
            $columnsToRename = [
                'product_id' => 'productId',
                'is_published' => 'isPublished',
                'is_featured' => 'isFeatured',
                'show_in_menu' => 'showInMenu',
                'sort_order' => 'sortOrder',
                'created_at' => 'createdAt',
                'updated_at' => 'updatedAt',
            ];
            $this->renameColumnsIfExists('kb_categories', $columnsToRename);
        }

        // KB Articles
        if (Schema::hasTable('kb_articles')) {
            $columnsToRename = [
                'kb_category_id' => 'kbCategoryId',
                'product_id' => 'productId',
                'is_published' => 'isPublished',
                'is_featured' => 'isFeatured',
                'allow_comments' => 'allowComments',
                'requires_serial' => 'requiresSerial',
                'serial_message' => 'serialMessage',
                'sort_order' => 'sortOrder',
                'meta_title' => 'metaTitle',
                'meta_description' => 'metaDescription',
                'meta_keywords' => 'metaKeywords',
                'created_at' => 'createdAt',
                'updated_at' => 'updatedAt',
            ];
            $this->renameColumnsIfExists('kb_articles', $columnsToRename);
        }
    }

    /**
     * Fix webhook tables columns
     */
    private function fixWebhookTables(): void
    {
        // Webhooks table
        if (Schema::hasTable('webhooks')) {
            $columnsToRename = [
                'is_active' => 'isActive',
                'failed_attempts' => 'failedAttempts',
                'last_successful_at' => 'lastSuccessfulAt',
                'last_failed_at' => 'lastFailedAt',
                'created_at' => 'createdAt',
                'updated_at' => 'updatedAt',
            ];
            $this->renameColumnsIfExists('webhooks', $columnsToRename);
        }

        // Webhook logs table
        if (Schema::hasTable('webhook_logs')) {
            $columnsToRename = [
                'webhook_id' => 'webhookId',
                'event_type' => 'eventType',
                'response_status' => 'responseStatus',
                'response_body' => 'responseBody',
                'execution_time' => 'executionTime',
                'is_successful' => 'isSuccessful',
                'error_message' => 'errorMessage',
                'created_at' => 'createdAt',
                'updated_at' => 'updatedAt',
            ];
            $this->renameColumnsIfExists('webhook_logs', $columnsToRename);
        }
    }

    /**
     * Rename columns if they exist
     */
    private function renameColumnsIfExists(string $tableName, array $columnMappings): void
    {
        foreach ($columnMappings as $oldName => $newName) {
            if (Schema::hasColumn($tableName, $oldName) && !Schema::hasColumn($tableName, $newName)) {
                try {
                    Schema::table($tableName, function (Blueprint $table) use ($oldName, $newName) {
                        $table->renameColumn($oldName, $newName);
                    });
                } catch (\Exception $e) {
                    // Log the error but continue with other columns
                    \Log::warning("Failed to rename column {$oldName} to {$newName} in table {$tableName}: " . $e->getMessage());
                }
            }
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // This migration is not reversible as it fixes data inconsistencies
        // If rollback is needed, restore from backup
    }
};