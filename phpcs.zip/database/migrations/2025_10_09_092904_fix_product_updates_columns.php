<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Fix product_updates table columns to use camelCase.
     */
    public function up(): void
    {
        if (!Schema::hasTable('product_updates')) {
            return;
        }

        // Rename columns from snake_case to camelCase
        $columnsToRename = [
            'is_active' => 'isActive',
            'is_major' => 'isMajor',
            'is_required' => 'isRequired',
            'file_path' => 'filePath',
            'file_name' => 'fileName',
            'file_hash' => 'fileHash',
            'released_at' => 'releasedAt',
        ];

        foreach ($columnsToRename as $oldName => $newName) {
            if (Schema::hasColumn('product_updates', $oldName) && !Schema::hasColumn('product_updates', $newName)) {
                try {
                    Schema::table('product_updates', function (Blueprint $table) use ($oldName, $newName) {
                        $table->renameColumn($oldName, $newName);
                    });
                } catch (\Exception $e) {
                    \Log::warning("Failed to rename column {$oldName} to {$newName} in product_updates: " . $e->getMessage());
                }
            }
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (!Schema::hasTable('product_updates')) {
            return;
        }

        // Rename columns back from camelCase to snake_case
        $columnsToRename = [
            'isActive' => 'is_active',
            'isMajor' => 'is_major',
            'isRequired' => 'is_required',
            'filePath' => 'file_path',
            'fileName' => 'file_name',
            'fileHash' => 'file_hash',
            'releasedAt' => 'released_at',
        ];

        foreach ($columnsToRename as $oldName => $newName) {
            if (Schema::hasColumn('product_updates', $oldName) && !Schema::hasColumn('product_updates', $newName)) {
                try {
                    Schema::table('product_updates', function (Blueprint $table) use ($oldName, $newName) {
                        $table->renameColumn($oldName, $newName);
                    });
                } catch (\Exception $e) {
                    \Log::warning("Failed to rename column {$oldName} to {$newName} in product_updates: " . $e->getMessage());
                }
            }
        }
    }
};