<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Fix final camelCase column issues.
     */
    public function up(): void
    {
        // Fix programming_languages table
        if (Schema::hasTable('programming_languages')) {
            $this->fixProgrammingLanguagesTable();
        }
    }

    /**
     * Fix programming_languages table columns
     */
    private function fixProgrammingLanguagesTable(): void
    {
        $columnsToRename = [
            'is_active' => 'isActive',
            'sort_order' => 'sortOrder',
        ];

        $this->renameColumnsIfExists('programming_languages', $columnsToRename);
    }

    /**
     * Rename columns if they exist
     */
    private function renameColumnsIfExists(string $tableName, array $columnMappings): void
    {
        foreach ($columnMappings as $oldName => $newName) {
            if (Schema::hasColumn($tableName, $oldName) && !Schema::hasColumn($tableName, $newName)) {
                try {
                    Schema::table($tableName, function (Blueprint $table) use ($oldName, $newName) {
                        $table->renameColumn($oldName, $newName);
                    });
                } catch (\Exception $e) {
                    \Log::warning("Failed to rename column {$oldName} to {$newName} in table {$tableName}: " . $e->getMessage());
                }
            }
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // This migration is not reversible as it fixes data inconsistencies
    }
};