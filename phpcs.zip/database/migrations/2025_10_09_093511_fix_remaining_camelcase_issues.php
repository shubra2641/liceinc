<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * Fix remaining camelCase column issues in various tables.
     */
    public function up(): void
    {
        // Fix product_categories table
        if (Schema::hasTable('product_categories')) {
            $this->fixProductCategoriesTable();
        }

        // Fix kb_categories table
        if (Schema::hasTable('kb_categories')) {
            $this->fixKbCategoriesTable();
        }

        // Fix products table
        if (Schema::hasTable('products')) {
            $this->fixProductsTable();
        }

        // Fix tickets table
        if (Schema::hasTable('tickets')) {
            $this->fixTicketsTable();
        }

        // Fix licenses table
        if (Schema::hasTable('licenses')) {
            $this->fixLicensesTable();
        }
    }

    /**
     * Fix product_categories table columns
     */
    private function fixProductCategoriesTable(): void
    {
        $columnsToRename = [
            'is_active' => 'isActive',
            'sort_order' => 'sortOrder',
            'parent_id' => 'parentId',
            'meta_title' => 'metaTitle',
            'meta_keywords' => 'metaKeywords',
            'meta_description' => 'metaDescription',
            'text_color' => 'textColor',
            'show_in_menu' => 'showInMenu',
            'is_featured' => 'isFeatured',
            'allow_subcategories' => 'allowSubcategories',
        ];

        $this->renameColumnsIfExists('product_categories', $columnsToRename);
    }

    /**
     * Fix kb_categories table columns
     */
    private function fixKbCategoriesTable(): void
    {
        $columnsToRename = [
            'is_active' => 'isActive',
            'is_published' => 'isPublished',
            'is_featured' => 'isFeatured',
            'show_in_menu' => 'showInMenu',
            'sort_order' => 'sortOrder',
            'parent_id' => 'parentId',
            'product_id' => 'productId',
        ];

        $this->renameColumnsIfExists('kb_categories', $columnsToRename);
    }

    /**
     * Fix products table columns
     */
    private function fixProductsTable(): void
    {
        $columnsToRename = [
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('products', $columnsToRename);
    }

    /**
     * Fix tickets table columns
     */
    private function fixTicketsTable(): void
    {
        $columnsToRename = [
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('tickets', $columnsToRename);
    }

    /**
     * Fix licenses table columns
     */
    private function fixLicensesTable(): void
    {
        $columnsToRename = [
            'product_id' => 'productId',
            'user_id' => 'userId',
            'created_at' => 'createdAt',
            'updated_at' => 'updatedAt',
        ];

        $this->renameColumnsIfExists('licenses', $columnsToRename);
    }

    /**
     * Rename columns if they exist
     */
    private function renameColumnsIfExists(string $tableName, array $columnMappings): void
    {
        foreach ($columnMappings as $oldName => $newName) {
            if (Schema::hasColumn($tableName, $oldName) && !Schema::hasColumn($tableName, $newName)) {
                try {
                    Schema::table($tableName, function (Blueprint $table) use ($oldName, $newName) {
                        $table->renameColumn($oldName, $newName);
                    });
                } catch (\Exception $e) {
                    \Log::warning("Failed to rename column {$oldName} to {$newName} in table {$tableName}: " . $e->getMessage());
                }
            }
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // This migration is not reversible as it fixes data inconsistencies
        // If rollback is needed, restore from backup
    }
};