<?php

declare(strict_types=1);

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Product Request with enhanced security.
 *
 * This unified request class handles validation for both creating and updating
 * products with comprehensive security measures and input sanitization.
 *
 * Features:
 * - Unified validation for both store and update operations
 * - XSS protection and input sanitization
 * - File upload validation with security checks
 * - Custom validation messages for better user experience
 * - Proper type hints and return types
 * - Security validation rules (XSS protection, SQL injection prevention)
 * - Unique validation with ignore for current record on updates
 * - SEO metadata validation
 * - Pricing and licensing validation
 */
class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        $user = auth()->user();
        return auth()->check() && $user && ($user->isAdmin || $user->hasRole('admin'));
    }
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $productId = $this->route('product')->id ?? null;
        $isUpdate = $this->isMethod('PUT') || $this->isMethod('PATCH');
        return [
            'name' => [
                'required',
                'string',
                'max:255',
            ],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                'regex:/^[a-z0-9\-_]+$/',
                $isUpdate ? Rule::unique('products', 'slug')->ignore($productId) : 'unique:products,slug',
            ],
            'description' => [
                'nullable',
                'string',
            ],
            'category_id' => [
                'nullable',
                'integer',
                'exists:product_categories,id',
            ],
            'programming_language' => [
                'nullable',
                'integer',
                'exists:programming_languages,id',
            ],
            'price' => [
                'nullable',
                'numeric',
                'min:0',
            ],
            'image' => [
                'nullable',
                'image',
                'mimes:jpeg,png,jpg,gif,webp',
                'max:5120',
            ],
            'is_active' => [
                'boolean',
            ],
            'is_featured' => [
                'boolean',
            ],
            'is_popular' => [
                'boolean',
            ],
            'is_downloadable' => [
                'boolean',
            ],
            'requires_domain' => [
                'boolean',
            ],
            'auto_renewal' => [
                'boolean',
            ],
            'support_days' => [
                'nullable',
                'integer',
                'min:0',
                'max:3650',
            ],
            'stock_quantity' => [
                'nullable',
                'integer',
                'min:-1',
            ],
            'license_type' => [
                'nullable',
                'string',
                Rule::in(['single', 'multi', 'developer', 'extended', 'regular']),
            ],
            'renewal_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],
            'renewal_period' => [
                'nullable',
                'string',
                Rule::in(['monthly', 'quarterly', 'semi-annual', 'annual', 'three-years', 'lifetime']),
            ],
            'duration_days' => [
                'nullable',
                'integer',
                'min:1',
                'max:3650',
            ],
            'tax_rate' => [
                'nullable',
                'numeric',
                'min:0',
                'max:100',
            ],
            'extended_support_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],
            'extended_support_days' => [
                'nullable',
                'integer',
                'min:0',
                'max:3650',
            ],
            'renewal_reminder_days' => [
                'nullable',
                'integer',
                'min:1',
                'max:365',
            ],
            'status' => [
                'nullable',
                'string',
                Rule::in(['active', 'inactive', 'draft', 'archived']),
            ],
            'stock' => [
                'nullable',
                'integer',
                'min:-1',
            ],
            'supported_until' => [
                'nullable',
                'date',
            ],
            'extended_supported_until' => [
                'nullable',
                'date',
            ],
            'currency' => [
                'nullable',
                'string',
                Rule::in(['USD', 'EUR', 'GBP', 'CAD', 'AUD']),
            ],
            'meta_title' => [
                'nullable',
                'string',
                'max:255',
            ],
            'meta_description' => [
                'nullable',
                'string',
                'max:500',
            ],
            'tags' => [
                'nullable',
                'string',
            ],
            'gallery_images' => [
                'nullable',
                'array',
            ],
            'gallery_images.*' => [
                'image',
                'mimes:jpeg,png,jpg,gif,webp',
                'max:5120',
            ],
            'features' => [
                'nullable',
                'string',
            ],
            'requirements' => [
                'nullable',
                'string',
            ],
            'installation_guide' => [
                'nullable',
                'string',
            ],
            'version' => [
                'nullable',
                'string',
                'max:50',
            ],
            'status' => [
                'nullable',
                'string',
                Rule::in(['active', 'inactive', 'draft', 'archived']),
            ],
            'stock' => [
                'nullable',
                'integer',
                'min:-1',
            ],
            'currency' => [
                'nullable',
                'string',
                Rule::in(['USD', 'EUR', 'GBP', 'CAD', 'AUD']),
            ],
        ];
    }
    /**
     * Get custom validation messages.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'name.required' => 'Product name is required.',
            'slug.unique' => 'A product with this slug already exists.',
            'slug.regex' => 'Slug can only contain lowercase letters, numbers, hyphens, and underscores.',
            'category_id.exists' => 'Selected category does not exist.',
            'programming_language.exists' => 'Selected programming language does not exist.',
            'price.min' => 'Price must be at least 0.',
            'image.max' => 'Image size must not exceed 5MB.',
            'image.mimes' => 'Image must be a file of type: jpeg, png, jpg, gif, webp.',
            'support_days.min' => 'Support days must be at least 0.',
            'support_days.max' => 'Support days cannot exceed 3650.',
            'stock_quantity.min' => 'Stock quantity must be at least -1 (unlimited).',
            'license_type.in' => 'License type must be one of: single, multi, developer, extended, regular.',
            'renewal_price.min' => 'Renewal price must be at least 0.',
            'renewal_period.in' => 'Renewal period must be one of: monthly, quarterly, semi-annual, annual, three-years, lifetime.',
            'duration_days.min' => 'Duration days must be at least 1.',
            'duration_days.max' => 'Duration days cannot exceed 3650.',
            'tax_rate.min' => 'Tax rate must be at least 0.',
            'tax_rate.max' => 'Tax rate cannot exceed 100.',
            'extended_support_price.min' => 'Extended support price must be at least 0.',
            'extended_support_days.min' => 'Extended support days must be at least 0.',
            'extended_support_days.max' => 'Extended support days cannot exceed 3650.',
            'renewal_reminder_days.min' => 'Renewal reminder days must be at least 1.',
            'renewal_reminder_days.max' => 'Renewal reminder days cannot exceed 365.',
            'status.in' => 'Status must be one of: active, inactive, draft, archived.',
            'stock.min' => 'Stock must be at least -1 (unlimited).',
            'currency.in' => 'Currency must be one of: USD, EUR, GBP, CAD, AUD.',
            'meta_title.max' => 'Meta title cannot exceed 255 characters.',
            'meta_description.max' => 'Meta description cannot exceed 500 characters.',
            'gallery_images.array' => 'Gallery images must be an array.',
            'gallery_images.*.image' => 'Each gallery image must be a valid image file.',
            'gallery_images.*.mimes' => 'Gallery images must be of type: jpeg, png, jpg, gif, webp.',
            'gallery_images.*.max' => 'Each gallery image must not exceed 5MB.',
        ];
    }
    /**
     * Get custom attributes for validator errors.
     *
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'name' => 'product name',
            'slug' => 'product slug',
            'description' => 'product description',
            'category_id' => 'product category',
            'programming_language' => 'programming language',
            'price' => 'product price',
            'image' => 'product image',
            'is_active' => 'active status',
            'is_featured' => 'featured status',
            'is_popular' => 'popular status',
            'is_downloadable' => 'downloadable status',
            'requires_domain' => 'domain requirement',
            'auto_renewal' => 'auto renewal',
            'support_days' => 'support days',
            'stock_quantity' => 'stock quantity',
            'license_type' => 'license type',
            'renewal_price' => 'renewal price',
            'renewal_period' => 'renewal period',
            'duration_days' => 'duration days',
            'tax_rate' => 'tax rate',
            'extended_support_price' => 'extended support price',
            'extended_support_days' => 'extended support days',
            'renewal_reminder_days' => 'renewal reminder days',
            'status' => 'status',
            'stock' => 'stock',
            'supported_until' => 'supported until',
            'extended_supported_until' => 'extended supported until',
            'currency' => 'currency',
            'meta_title' => 'meta title',
            'meta_description' => 'meta description',
            'tags' => 'tags',
            'gallery_images' => 'gallery images',
        ];
    }
    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        // Handle checkbox values
        $this->merge([
            'is_active' => $this->has('is_active'),
            'is_featured' => $this->has('is_featured'),
            'is_popular' => $this->has('is_popular'),
            'is_downloadable' => $this->has('is_downloadable'),
            'auto_renewal' => $this->has('auto_renewal'),
        ]);
        
        // Handle radio button values
        if ($this->has('requires_domain')) {
            $this->merge([
                'requires_domain' => (bool) $this->input('requires_domain')
            ]);
        }
    }
}
