<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Webhook Model
 *
 * @property int $id
 * @property string $name
 * @property string $url
 * @property string $secret
 * @property bool $isActive
 * @property int $failed_attempts
 * @property \Carbon\Carbon|null $last_successful_at
 * @property \Carbon\Carbon|null $last_failed_at
 * @property \Carbon\Carbon|null $createdAt
 * @property \Carbon\Carbon|null $updatedAt
 */
class Webhook extends Model
{
    /**
     * @phpstan-ignore-next-line
     */
    use HasFactory;

    /**
     * @phpstan-ignore-next-line
     */
    protected static $factory = WebhookFactory::class;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    /**
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'url',
        'secret',
        'isActive',
        'failedAttempts',
        'lastSuccessfulAt',
        'lastFailedAt',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'isActive' => 'boolean',
        'failedAttempts' => 'integer',
        'lastSuccessfulAt' => 'datetime',
        'lastFailedAt' => 'datetime',
    ];

    /**
     * Get the webhook logs for the webhook.
     */
    /**
     * @return HasMany
     */
    /**
     * @return HasMany<WebhookLog, $this>
     */
    public function logs(): HasMany
    {
        return $this->hasMany(WebhookLog::class);
    }

    /**
     * Scope a query to only include active webhooks.
     */
    /**
     * @param \Illuminate\Database\Eloquent\Builder<Webhook> $query
     *
     * @return \Illuminate\Database\Eloquent\Builder<Webhook>
     */
    public function scopeActive($query)
    {
        return $query->where('isActive', true);
    }

    /**
     * Scope a query to only include failed webhooks.
     */
    /**
     * @param \Illuminate\Database\Eloquent\Builder<Webhook> $query
     *
     * @return \Illuminate\Database\Eloquent\Builder<Webhook>
     */
    public function scopeFailed($query)
    {
        return $query->where('failedAttempts', '>', 0);
    }
}
