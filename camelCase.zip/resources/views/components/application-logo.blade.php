<i class="fas fa-cube text-primary" {{ $attributes }}></i>
