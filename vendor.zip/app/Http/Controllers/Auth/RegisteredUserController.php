<?php

namespace App\Http\Controllers\Auth;

use App\Helpers\ConfigHelper;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\EmailService;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

/**
 * Controller for handling user registration requests with enhanced security.
 *
 * This controller manages user registration with comprehensive validation,
 * anti-spam protection, and email notifications. It includes support for
 * Google reCAPTCHA and human verification questions.
 *
 * Features:
 * - Enhanced security measures (XSS protection, input validation)
 * - Comprehensive error handling with database transactions
 * - Proper logging for errors and warnings only
 * - Anti-spam protection with reCAPTCHA and human questions
 * - Email verification and notification system
 *
 * @author My-Logos Team
 *
 * @version 1.0.6
 */
class RegisteredUserController extends Controller
{
    protected EmailService $emailService;

    /**
     * Create a new controller instance.
     *
     * @param  EmailService  $emailService  The email service for sending notifications
     */
    public function __construct(EmailService $emailService)
    {
        $this->emailService = $emailService;
    }

    /**
     * Display the registration view.
     *
     * Shows the user registration form with all necessary fields
     * and anti-spam protection options.
     *
     * @return View The registration view
     */
    public function create(): View
    {
        $registrationSettings = $this->getRegistrationSettings();
        return view('auth.register', compact('registrationSettings'));
    }

    /**
     * Handle an incoming registration request with enhanced security.
     *
     * Validates user input, performs anti-spam checks, creates the user,
     * sends welcome and notification emails, and logs the user in.
     *
     * @param  Request  $request  The registration request
     *
     * @return RedirectResponse Redirect to dashboard on success or back with errors
     *
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Exception When database operations fail
     */
    public function store(Request $request): RedirectResponse
    {
        try {
            DB::beginTransaction();

            $this->validateRegistrationRequest($request);

            $this->validateAntiSpamProtection($request);

            $user = $this->createUser($request);

            $this->handleUserRegistration($user);

            Auth::login($user);

            DB::commit();

            return redirect(route('dashboard', absolute: false));
        } catch (\Illuminate\Validation\ValidationException $e) {
            DB::rollBack();
            throw $e;
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('User registration failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'ip' => $request->ip(),
                'user_agent' => $request->userAgent(),
            ]);

            return back()->withInput($request->except('password', 'password_confirmation'))
                ->withErrors(['email' => 'Registration failed. Please try again.']);
        }
    }

    /**
     * Validate the basic registration request with enhanced security.
     *
     * @param  Request  $request  The current request
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    private function validateRegistrationRequest(Request $request): void
    {
        $request->validate([
            'firstname' => ['required', 'string', 'max:255', 'regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'string', 'max:255', 'regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:'.User::class],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'phonenumber' => ['nullable', 'string', 'max:50', 'regex:/^[\+]?[0-9\s\-\(\)]+$/'],
            'country' => ['nullable', 'string', 'max:100', 'regex:/^[a-zA-Z\s]+$/'],
        ], [
            'firstname.regex' => 'First name can only contain letters and spaces.',
            'lastname.regex' => 'Last name can only contain letters and spaces.',
            'phonenumber.regex' => 'Phone number contains invalid characters.',
            'country.regex' => 'Country name can only contain letters and spaces.',
        ]);
    }

    /**
     * Validate anti-spam protection mechanisms.
     *
     * @param  Request  $request  The current request
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    private function validateAntiSpamProtection(Request $request): void
    {
        $this->validateCaptcha($request);
        $this->validateHumanQuestion($request);
    }

    /**
     * Validate Google reCAPTCHA if enabled.
     *
     * @param  Request  $request  The current request
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    private function validateCaptcha(Request $request): void
    {
        $enableCaptcha = ConfigHelper::getSetting('enable_captcha', false);
        $captchaSecret = ConfigHelper::getSetting('captcha_secret_key', '');

        if (! $enableCaptcha || ! $captchaSecret) {
            return;
        }

        $token = $request->input('g-recaptcha-response');
        if (empty($token)) {
            throw new \Illuminate\Validation\ValidationException(
                validator([], []),
                ['g-recaptcha-response' => [__('Please complete the captcha')]],
            );
        }

        if (! $this->verifyRecaptcha($token, $captchaSecret, $request->ip())) {
            throw new \Illuminate\Validation\ValidationException(
                validator([], []),
                ['g-recaptcha-response' => [__('Captcha verification failed')]],
            );
        }
    }

    /**
     * Validate human verification question if enabled.
     *
     * @param  Request  $request  The current request
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    private function validateHumanQuestion(Request $request): void
    {
        $enableHumanQuestion = ConfigHelper::getSetting('enable_human_question', true);

        if (! $enableHumanQuestion) {
            return;
        }

        $humanQuestions = $this->getHumanQuestions();
        $given = strtolower(trim((string)$request->input('human_answer', '')));
        $index = $request->input('human_question_index', null);

        if (! $this->isValidHumanAnswer($given, $index, $humanQuestions)) {
            throw new \Illuminate\Validation\ValidationException(
                validator([], []),
                ['human_answer' => [__('Incorrect answer to the anti-spam question')]],
            );
        }
    }

    /**
     * Get human questions from configuration.
     *
     * @return array The human questions array
     */
    private function getHumanQuestions(): array
    {
        $humanQuestionsJson = ConfigHelper::getSetting('human_questions', null);

        if (empty($humanQuestionsJson)) {
            return [];
        }

        try {
            return json_decode($humanQuestionsJson, true) ?: [];
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Check if the human answer is valid.
     *
     * @param  string  $given  The given answer
     * @param  mixed  $index  The question index
     * @param  array  $humanQuestions  The human questions array
     *
     * @return bool True if answer is valid, false otherwise
     */
    private function isValidHumanAnswer(string $given, $index, array $humanQuestions): bool
    {
        if ($given === '') {
            return false;
        }

        if ($index === null || ! isset($humanQuestions[$index])) {
            $expected = ConfigHelper::getSetting('human_question_answer', '5');

            return strtolower(trim((string)$expected)) === $given;
        }

        $expected = strtolower(trim((string)($humanQuestions[$index]['answer'] ?? '')));

        return $expected === $given;
    }

    /**
     * Create a new user from the request data with enhanced security.
     *
     * @param  Request  $request  The current request
     *
     * @return User The created user
     */
    private function createUser(Request $request): User
    {
        return User::create([
            'name' => $this->sanitizeInput($request->firstname).' '.$this->sanitizeInput($request->lastname),
            'firstname' => $this->sanitizeInput($request->firstname),
            'lastname' => $this->sanitizeInput($request->lastname),
            'email' => $this->sanitizeInput($request->email),
            'password' => Hash::make($request->password),
            'phonenumber' => $this->sanitizeInput($request->phonenumber),
            'country' => $this->sanitizeInput($request->country),
        ]);
    }

    /**
     * Handle post-registration tasks.
     *
     * @param  User  $user  The registered user
     */
    private function handleUserRegistration(User $user): void
    {
        event(new Registered($user));
        $this->sendWelcomeEmail($user);
        $this->sendAdminNotification($user);
    }

    /**
     * Send welcome email to the new user.
     *
     * @param  User  $user  The registered user
     */
    private function sendWelcomeEmail(User $user): void
    {
        try {
            $this->emailService->sendWelcome($user, [
                'registration_date' => now()->format('Y-m-d H:i:s'),
            ]);
        } catch (\Exception $e) {
            // Silently handle email errors to not fail registration
        }
    }

    /**
     * Send admin notification about new user registration.
     *
     * @param  User  $user  The registered user
     */
    private function sendAdminNotification(User $user): void
    {
        try {
            $this->emailService->sendNewUserNotification($user);
        } catch (\Exception $e) {
            // Silently handle email errors to not fail registration
        }
    }

    /**
     * Verify Google reCAPTCHA token with Google's API.
     *
     * @param  string  $token  The reCAPTCHA token
     * @param  string  $secret  The reCAPTCHA secret key
     * @param  string|null  $remoteIp  The remote IP address
     *
     * @return bool True if verification successful, false otherwise
     */
    private function verifyRecaptcha(string $token, string $secret, ?string $remoteIp = null): bool
    {
        try {
            $response = Http::asForm()->post('https://www.google.com/recaptcha/api/siteverify', [
                'secret' => $secret,
                'response' => $token,
                'remoteip' => $remoteIp,
            ]);

            if (! $response->ok()) {
                return false;
            }

            $body = $response->json();

            return isset($body['success']) && $body['success'] === true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get registration settings for the view.
     *
     * @return array The registration settings
     */
    private function getRegistrationSettings(): array
    {
        $enableCaptcha = ConfigHelper::getSetting('enable_captcha', false);
        $captchaSiteKey = ConfigHelper::getSetting('captcha_site_key', '');
        $enableHumanQuestion = ConfigHelper::getSetting('enable_human_question', true);
        $humanQuestionsJson = ConfigHelper::getSetting('human_questions', null);
        
        $humanQuestions = [];
        if (!empty($humanQuestionsJson)) {
            try {
                $humanQuestions = json_decode($humanQuestionsJson, true) ?: [];
            } catch (\Exception $e) {
                $humanQuestions = [];
            }
        }

        // Choose a random question (server-side) and include its index in a hidden field
        $selectedQuestionIndex = null;
        $selectedQuestionText = null;
        if (!empty($humanQuestions) && is_array($humanQuestions)) {
            $selectedQuestionIndex = array_rand($humanQuestions);
            $selectedQuestion = $humanQuestions[$selectedQuestionIndex] ?? null;
            $selectedQuestionText = $selectedQuestion['question'] ?? null;
        }

        return [
            'enableCaptcha' => $enableCaptcha,
            'captchaSiteKey' => $captchaSiteKey,
            'enableHumanQuestion' => $enableHumanQuestion,
            'selectedQuestionIndex' => $selectedQuestionIndex,
            'selectedQuestionText' => $selectedQuestionText,
        ];
    }
}
