<?php
$content = file_get_contents('app/Http/Controllers/Admin/InvoiceController.php');
$lines = explode("\n", $content);
echo "Line 89: '" . $lines[88] . "'\n";
echo "Hex: " . bin2hex($lines[88]) . "\n";
?>