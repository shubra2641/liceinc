<?php

declare(strict_types=1);

return [
    'previous' => '&laquo; Previous',
    'next' => 'Next &raquo;',
];
