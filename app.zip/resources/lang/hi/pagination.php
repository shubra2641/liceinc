<?php

declare(strict_types=1);

return [
    'previous' => '&laquo; पिछला',
    'next' => 'अगला &raquo;',
];
