<?php

declare(strict_types=1);

return [
    // Welcome Page
    'welcome_title' => 'नमस्ते लाइसेंस प्रबंधन सिस्टम में',
    'welcome_subtitle' => 'आपके सिस्टम को केवल कुछ चरणों में चलाने के लिए आइए शुरू करें',
    'welcome_description' => 'इस स्थापना विज़र्ड आपको लाइसेंस प्रबंधन सिस्टम को स्थापना करने के लिए चलाएंगे। ' .
        'प्रक्रिया लगभग 5-10 मिनट लेगी।',
    'get_started' => 'शुरू करें',
    'what_we_will_setup' => 'हम क्या सेट अप करेंगे:',
    'select_language' => 'भाषा चुनें',
    'what_we_setup' => 'हम क्या सेट अप करेंगे:',

    // Steps
    'step_requirements' => 'सिस्टम आवश्यकताएं जांच',
    'step_requirements_desc' => 'सिस्टम आवश्यकताएं जांच करें और संगतता जांच करें',
    'step_database' => 'डाटाबेस कॉन्फ़िगरेशन',
    'step_database_desc' => 'डाटाबेस कनेक्शन सेटिंग्स कॉन्फ़िगर करें',
    'step_admin' => 'एडमिन खाता बनाएं',
    'step_admin_desc' => 'एडमिन खाता बनाएं',
    'step_settings' => 'सिस्टम सेटिंग्स',
    'step_settings_desc' => 'सिस्टम प्राथमिकताएं कॉन्फ़िगर करें',
    'step_install' => 'डाटाबेस स्थापना',
    'step_install_desc' => 'डाटाबेस स्थापना करें और मिग्रेशन चलाएं',
    'step_complete' => 'अंतिम सेटअप',
    'step_complete_desc' => 'अंतिम स्थापना और सेटअप करें',

    // Requirements Page
    'requirements_title' => 'सिस्टम आवश्यकताएं',
    'requirements_subtitle' => 'आपके सर्वर कि क्या आवश्यकताएं पूरी हैं यह जांचें',
    'requirements_all_passed' => 'सभी आवश्यकताएं पूरी हैं! आप स्थापना के साथ जारी रख सकते हैं।',
    'requirements_some_failed' => 'कुछ आवश्यकताएं पूरी नहीं हैं। कृपया नीचे दिए गए मुद्दों को ठीक करें और जारी रखें।',
    'requirement_passed' => 'पास हुआ',
    'requirement_failed' => 'फेल हुआ',
    'continue' => 'जारी रखें',
    'back' => 'पीछे',
    'fix_requirements_first' => 'आवश्यकताएं पहले ठीक करें',

    // Database Page
    'database_title' => 'डाटाबेस कॉन्फ़िगरेशन',
    'database_subtitle' => 'आपके डाटाबेस कनेक्शन विवरण दर्ज करें',
    'database_description' =>
        'Make sure your database server is running and the database exists. ' .
        'The installer will create the necessary tables.',
    'database_host' => 'डाटाबेस होस्ट',
    'database_port' => 'डाटाबेस पोर्ट',
    'database_name' => 'डाटाबेस नाम',
    'database_username' => 'डाटाबेस उपयोगकर्ता नाम',
    'database_password' => 'डाटाबेस पासवर्ड',
    'test_connection' => 'टेस्ट कनेक्शन',
    'test_connection_continue' => 'टेस्ट कनेक्शन & जारी रखें',
    'testing' => 'टेस्टिंग...',
    'processing' => 'प्रसंग...',

    // Admin Page
    'admin_title' => 'एडमिन खाता',
    'admin_subtitle' => 'आपके एडमिन खाता बनाएं',
    'admin_description' => 'यह खाता सिस्टम के लिए पूर्ण प्रवेश होगा। कृपया एक मजबूत पासवर्ड उपयोग करें।',
    'admin_name' => 'पूरा नाम',
    'admin_email' => 'ईमेल पता',
    'admin_password' => 'पासवर्ड',
    'admin_password_confirmation' => 'पासवर्ड की पुष्टि करें',
    'password_requirements' => 'पासवर्ड कम से कम 8 अक्षरों का होना चाहिए ' .
        'और अक्षरों, संख्याओं और सिंबोलों का मिश्रण होना चाहिए।',
    'create_admin_account' => 'एडमिन खाता बनाएं',

    // Settings Page
    'settings_title' => 'सिस्टम सेटिंग्स',
    'settings_subtitle' => 'सिस्टम प्राथमिकताएं कॉन्फ़िगर करें',
    'settings_description' => 'आप इन सेटिंग्स को बाद में एडमिन पैनल से बदल सकते हैं। एडमिन पैनल से',
    'site_name' => 'साइट नाम',
    'site_description' => 'साइट विवरण',
    'timezone' => 'टाइमज़ोन',
    'default_language' => 'डिफ़ॉल्ट भाषा',
    'save_settings' => 'सेटिंग्स सेव करें',

    // Installation Page
    'install_title' => 'स्थापना',
    'install_subtitle' => 'आपके लाइसेंस प्रबंधन सिस्टम को स्थापना करें',
    'install_description' => 'यह प्रक्रिया कुछ मिनट ले सकती है। कृपया इस विंडो को बंद न करें।',
    'start_installation' => 'स्थापना शुरू करें',
    'installing' => 'स्थापना...',
    'updating_configuration' => 'संयोजन अद्यतन करें',
    'updating_configuration_desc' => 'वातावरण संयोजन फ़ाइलें अद्यतन करें...',
    'creating_database_tables' => 'डाटाबेस टेबल बनाएं',
    'creating_database_tables_desc' => 'डाटाबेस मिग्रेशन चलाएं...',
    'seeding_database' => 'डाटाबेस सीडिंग',
    'seeding_database_desc' => 'आरंभिक डेटा (टिकट, भाषाएं, ईमेल टेम्प्लेट्स) जोड़ें...',
    'setting_up_roles_permissions' => 'भूमिकाएं और अनुमतियां सेट करें',
    'setting_up_roles_permissions_desc' => 'उपयोगकर्ता भूमिकाएं और अनुमतियां बनाएं...',
    'creating_admin_account' => 'एडमिन खाता बनाएं',
    'creating_admin_account_desc' => 'एडमिन खाता सेट करें...',
    'configuring_system_settings' => 'सिस्टम सेटिंग्स कॉन्फ़िगर करें',
    'configuring_system_settings_desc' => 'सिस्टम संयोजन लागू करें...',
    'creating_storage_link' => 'स्टोरेज लिंक बनाएं',
    'creating_storage_link_desc' => 'स्टोरेज डायरेक्टरी लिंक करें फ़ाइल एक्सेस के लिए',
    'finalizing_installation' => 'स्थापना पूरी करें',
    'finalizing_installation_desc' => 'स्थापना प्रक्रिया पूरी करें...',

    // Additional translations
    'step_welcome' => 'स्वागत',
    'required' => 'आवश्यक',
    'current' => 'वर्तमान',
    'requirements_success_message' => 'आपका सर्वर इस एप्लिकेशन को चलाने के लिए सभी आवश्यकताएं पूरी करता है।',
    'requirements_failed_message' => 'कृपया फेल हुए आवश्यकताएं जारी रखने से पहले ठीक करें।',
    'fix_requirements' => 'आवश्यकताएं पहले ठीक करें',
    'password_hint' => 'पासवर्ड कम से कम 8 अक्षरों का होना चाहिए',
    'admin_email_hint' => 'इसका उपयोग सिस्टम अधिसूचनाओं के लिए किया जाएगा',
    'javascript_required_for_email_settings' =>
        'डायनामिक ईमेल सेटिंग्स के लिए JavaScript आवश्यक है। ' .
        'कृपया JavaScript सक्षम करें या मैन्युअल रूप से ईमेल सेटिंग्स कॉन्फ़िगर करें।',
    'javascript_required_for_language_switching' =>
        'डायनामिक भाषा स्विचिंग के लिए JavaScript आवश्यक है। ' .
        'कृपया JavaScript सक्षम करें या भाषा बदलने के बाद पेज रिफ्रेश करें।',
    'javascript_required_for_password_validation' =>
        'रियल-टाइम पासवर्ड सत्यापन के लिए JavaScript आवश्यक है। ' .
        'बेहतर उपयोगकर्ता अनुभव के लिए कृपया JavaScript सक्षम करें।',

    // Success Messages
    'installation_complete' => 'स्थापना पूरी है!',
    'installation_complete_subtitle' => 'आपका लाइसेंस प्रबंधन सिस्टम उपयोग के लिए 準備ができています。',
    'installation_success' => 'स्थापना सफलतापूर्वक पूरी है! लॉग इन पृष्ठ पर रीडायरेक्ट करें...',

    // Error Messages
    'validation_errors' => 'सत्यापन त्रुटियां',
    'database_connection_failed' => 'डाटाबेस कनेक्शन फेल हुआ',
    'installation_failed' => 'स्थापना फेल हुआ',
    'system_already_installed' => 'सिस्टम पहले से स्थापित है।',

    // Form Validation
    'field_required' => 'यह फ़ील्ड आवश्यक है',
    'invalid_email' => 'कृपया एक मान्य ईमेल पता दर्ज करें',
    'password_too_short' => 'पासवर्ड कम से कम 8 अक्षरों का होना चाहिए',
    'passwords_do_not_match' => 'पासवर्ड मेल नहीं है',
    'invalid_port' => 'पोर्ट 1 और 65535 के बीच होना चाहिए',

    // Progress
    'step_of' => 'कदम :current का :total',

    // Timezones
    'timezone_utc' => 'UTC',
    'timezone_america_new_york' => 'America/New_York',
    'timezone_america_chicago' => 'अमेरिका/चिकगो',
    'timezone_america_denver' => 'अमेरिका/डेन्वर',
    'timezone_america_los_angeles' => 'अमेरिका/लोस एंजेल्स',
    'timezone_europe_london' => 'यूरोप/लंडन',
    'timezone_europe_paris' => 'यूरोप/पैरिस',
    'timezone_europe_berlin' => 'यूरोप/बर्लिन',
    'timezone_asia_tokyo' => 'एशिया/टोक्यो',
    'timezone_asia_shanghai' => 'एशिया/शंघाई',
    'timezone_asia_dubai' => 'एशिया/दबै',
    'timezone_asia_riyadh' => 'एशिया/रायद',

    // Languages
    'language_english' => 'इंग्लिश',
    'language_arabic' => 'अरबी',

    // Completion Page
    'completion_title' => 'स्थापना पूरी है',
    'completion_subtitle' => 'आपका सिस्टम सफलतापूर्वक स्थापित और कॉन्फ़िगर किया गया है',
    'installation_completed' => 'स्थापना सफलतापूर्वक पूरी है!',
    'installation_success_message' => 'बधाई हो! आपका लाइसेंस प्रबंधन सिस्टम सफलतापूर्वक ' .
        'स्थापित और कॉन्फ़िगर किया गया है।',
    'admin_account_created' => 'एडमिन खाता बनाया गया',
    'account_status' => 'स्थिति',
    'email_verified' => 'ईमेल सत्यापित',
    'system_information' => 'सिस्टम जानकारी',
    'database_connected' => 'डाटाबेस',
    'important_notice' => 'महत्वपूर्ण सुरक्षा सूचना',
    'delete_install_folder_warning' => 'सुरक्षा कारणों के लिए, कृपया इंस्टाल फ़ोल्डर को ' .
        'इंस्टालेशन प्रक्रिया पूरी करने के बाद हटाएं।',
    'next_steps' => 'अगले कदम',
    'delete_install_folder' => 'इंस्टाल फ़ोल्डर हटाएं',
    'delete_install_folder_description' => 'इंस्टाल डायरेक्टरी हटाएं इंस्टालेशन विज़र्ड के लिए ' .
        'अनुमति देने से बचाएं।',
    'configure_system' => 'सिस्टम कॉन्फ़िगर करें',
    'configure_system_description' => 'एडमिन पैनल से प्रवेश करें अपने सिस्टम सेटिंग्स ' .
        'और प्राथमिकताओं को कॉन्फ़िगर करने के लिए।',
    'secure_system' => 'सिस्टम सुरक्षित करें',
    'secure_system_description' => 'सुरक्षा सेटिंग्स को समीक्षा करें और अतिरिक्त सुरक्षा मापों को कॉन्फ़िगर करें।',
    'go_to_admin_panel' => 'एडमिन पैनल पर जाएं',
    'go_to_frontend' => 'फ्रंटएंड पर जाएं',
    'completion_note' => 'आप हमेशा एडमिन पैनल से फ्रंटएंड से प्रवेश कर सकते हैं ' .
        'अपने एडमिन खाते से लॉग इन करके।',
    'database_created' => 'डाटाबेस बनाया गया',
    'system_configured' => 'सिस्टम कॉन्फ़िगर किया गया',
    // Email Configuration
    'email_configuration' => 'ईमेल कॉन्फ़िगरेशन',
    'email_configuration_subtitle' => 'ईमेल सेटिंग्स को कॉन्फ़िगर करें अधिसूचनाओं ' .
        'और सिस्टम ईमेल (वैकल्पिक)',
    'enable_email_notifications' => 'ईमेल सूचनाओं को सक्षम करें',
    'enable_email_hint' => 'ईमेल सेटिंग्स को कॉन्फ़िगर करने के लिए इसे जांचें। ' .
        'आप इसे छोड़ सकते हैं और बाद में एडमिन पैनल से कॉन्फ़िगर कर सकते हैं।',
    'mail_mailer' => 'Mail Driver मेल ड्राइवर',
    'mail_host' => 'SMTP होस्ट',
    'mail_port' => 'SMTP पोर्ट',
    'mail_encryption' => 'Encryption एन्क्रिप्शन    ',
    'mail_username' => 'SMTP उपयोगकर्ता नाम',
    'mail_password' => 'SMTP पासवर्ड',
    'mail_password_placeholder' => 'ईमेल पासवर्ड या एप पासवर्ड दर्ज करें',
    'mail_password_hint' => 'जीमेल के लिए, अपना नियमित पासवर्ड के बजाय एप पासवर्ड उपयोग करें',
    'mail_from_address' => 'ईमेल पता',
    'mail_from_name' => 'ईमेल पता',
    'mail_from_name_placeholder' => 'Your Company Name आपकी कंपनी का नाम',
];
