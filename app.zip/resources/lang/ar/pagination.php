<?php

declare(strict_types=1);

return [
    'previous' => '&laquo; السابق',
    'next' => 'التالي &raquo;',
];
