<?php

declare(strict_types=1);

return [
    // Welcome Page
    'welcome_title' => 'مرحباً بك في نظام إدارة التراخيص',
    'welcome_subtitle' => 'دعنا ننشئ نظامك في خطوات قليلة',
    'welcome_description' => 'سيرشدك معالج التثبيت خلال إعداد نظام إدارة التراخيص الخاص بك. ' .
        'العملية تستغرق حوالي 5-10 دقائق.',
    'get_started' => 'ابدأ الآن',
    'what_we_will_setup' => 'ما سنقوم بإعداده:',
    'select_language' => 'اختر اللغة',
    'what_we_setup' => 'ما سنقوم بإعداده:',

    // Steps
    'step_requirements' => 'فحص متطلبات النظام',
    'step_requirements_desc' => 'فحص متطلبات النظام والتوافق',
    'step_database' => 'إعداد قاعدة البيانات',
    'step_database_desc' => 'تكوين إعدادات اتصال قاعدة البيانات',
    'step_admin' => 'إنشاء حساب الإدارة',
    'step_admin_desc' => 'إنشاء حساب المدير',
    'step_settings' => 'إعدادات النظام',
    'step_settings_desc' => 'تكوين تفضيلات النظام',
    'step_install' => 'تثبيت قاعدة البيانات',
    'step_install_desc' => 'تثبيت قاعدة البيانات وتشغيل migrations',
    'step_complete' => 'الإعداد النهائي',
    'step_complete_desc' => 'إنهاء التثبيت والإعداد',

    // Requirements Page
    'requirements_title' => 'متطلبات النظام',
    'requirements_subtitle' => 'دعنا نتحقق من أن خادمك يلبي المتطلبات',
    'requirements_all_passed' => 'جميع المتطلبات متوفرة! يمكنك المتابعة مع التثبيت.',
    'requirements_some_failed' => 'بعض المتطلبات غير متوفرة. يرجى إصلاح المشاكل أدناه قبل المتابعة.',
    'requirement_passed' => 'متوفر',
    'requirement_failed' => 'غير متوفر',
    'continue' => 'متابعة',
    'back' => 'رجوع',
    'fix_requirements_first' => 'أصلح المتطلبات أولاً',

    // Database Page
    'database_title' => 'إعداد قاعدة البيانات',
    'database_subtitle' => 'أدخل تفاصيل اتصال قاعدة البيانات',
    'database_description' =>
    'تأكد من أن خادم قاعدة البيانات يعمل وأن قاعدة البيانات موجودة. سيقوم المثبت بإنشاء الجداول اللازمة.',
    'database_host' => 'مضيف قاعدة البيانات',
    'database_port' => 'منفذ قاعدة البيانات',
    'database_name' => 'اسم قاعدة البيانات',
    'database_username' => 'اسم مستخدم قاعدة البيانات',
    'database_password' => 'كلمة مرور قاعدة البيانات',
    'test_connection' => 'اختبار الاتصال',
    'test_connection_continue' => 'اختبار الاتصال والمتابعة',
    'testing' => 'جاري الاختبار...',
    'processing' => 'جاري المعالجة...',

    // Admin Page
    'admin_title' => 'حساب الإدارة',
    'admin_subtitle' => 'أنشئ حساب المدير الخاص بك',
    'admin_description' => 'هذا الحساب سيكون له صلاحية كاملة على النظام. تأكد من استخدام كلمة مرور قوية.',
    'admin_name' => 'الاسم الكامل',
    'admin_email' => 'عنوان البريد الإلكتروني',
    'admin_password' => 'كلمة المرور',
    'admin_password_confirmation' => 'تأكيد كلمة المرور',
    'password_requirements' => 'يجب أن تكون كلمة المرور 8 أحرف على الأقل وتحتوي على مزيج من الأحرف والأرقام والرموز.',
    'create_admin_account' => 'إنشاء حساب الإدارة',

    // Settings Page
    'settings_title' => 'إعدادات النظام',
    'settings_subtitle' => 'قم بتكوين تفضيلات النظام',
    'settings_description' => 'يمكنك تغيير هذه الإعدادات لاحقاً من لوحة الإدارة.',
    'site_name' => 'اسم الموقع',
    'site_description' => 'وصف الموقع',
    'timezone' => 'المنطقة الزمنية',
    'default_language' => 'اللغة الافتراضية',
    'save_settings' => 'حفظ الإعدادات',

    // Installation Page
    'install_title' => 'التثبيت',
    'install_subtitle' => 'تثبيت نظام إدارة التراخيص الخاص بك',
    'install_description' => 'قد تستغرق هذه العملية بضع دقائق. يرجى عدم إغلاق هذه النافذة.',
    'start_installation' => 'بدء التثبيت',
    'installing' => 'جاري التثبيت...',
    'updating_configuration' => 'تحديث التكوين',
    'updating_configuration_desc' => 'تحديث ملفات تكوين البيئة...',
    'creating_database_tables' => 'إنشاء جداول قاعدة البيانات',
    'creating_database_tables_desc' => 'تشغيل migrations قاعدة البيانات...',
    'seeding_database' => 'إضافة البيانات الأولية',
    'seeding_database_desc' => 'إضافة البيانات الأولية (التذاكر، لغات البرمجة، قوالب البريد)...',
    'setting_up_roles_permissions' => 'إعداد الأدوار والصلاحيات',
    'setting_up_roles_permissions_desc' => 'إنشاء أدوار المستخدمين والصلاحيات...',
    'creating_admin_account' => 'إنشاء حساب الإدارة',
    'creating_admin_account_desc' => 'إعداد حساب المدير...',
    'configuring_system_settings' => 'تكوين إعدادات النظام',
    'configuring_system_settings_desc' => 'تطبيق تكوين النظام...',
    'creating_storage_link' => 'إنشاء رابط التخزين',
    'creating_storage_link_desc' => 'ربط مجلد التخزين للوصول للملفات',
    'finalizing_installation' => 'إنهاء التثبيت',
    'finalizing_installation_desc' => 'إكمال عملية التثبيت...',

    // Additional translations
    'step_welcome' => 'الترحيب',
    'required' => 'مطلوب',
    'current' => 'الحالي',
    'requirements_success_message' => 'يلبي الخادم الخاص بك جميع المتطلبات لتشغيل هذا التطبيق.',
    'requirements_failed_message' => 'يرجى إصلاح المتطلبات الفاشلة قبل المتابعة.',
    'fix_requirements' => 'أصلح المتطلبات أولاً',
    'password_hint' => 'يجب أن تكون كلمة المرور 8 أحرف على الأقل',
    'admin_email_hint' => 'سيتم استخدام هذا للإشعارات النظام',
    'javascript_required_for_email_settings' =>
        'JavaScript مطلوب لإعدادات البريد الإلكتروني الديناميكية. ' .
        'يرجى تفعيل JavaScript أو تكوين إعدادات البريد الإلكتروني يدوياً.',
    'javascript_required_for_language_switching' =>
        'JavaScript مطلوب لتبديل اللغة الديناميكي. ' .
        'يرجى تفعيل JavaScript أو تحديث الصفحة بعد تغيير اللغة.',
    'javascript_required_for_password_validation' =>
        'JavaScript مطلوب للتحقق من كلمة المرور في الوقت الفعلي. ' .
        'يرجى تفعيل JavaScript للحصول على تجربة مستخدم أفضل.',

    // Success Messages
    'installation_complete' => 'تم التثبيت بنجاح!',
    'installation_complete_subtitle' => 'نظام إدارة التراخيص الخاص بك جاهز للاستخدام.',
    'installation_success' => 'تم التثبيت بنجاح! جاري التوجيه لصفحة تسجيل الدخول...',

    // Error Messages
    'validation_errors' => 'أخطاء التحقق',
    'database_connection_failed' => 'فشل الاتصال بقاعدة البيانات',
    'installation_failed' => 'فشل التثبيت',
    'system_already_installed' => 'النظام مثبت بالفعل.',

    // Form Validation
    'field_required' => 'هذا الحقل مطلوب',
    'invalid_email' => 'يرجى إدخال عنوان بريد إلكتروني صحيح',
    'password_too_short' => 'يجب أن تكون كلمة المرور 8 أحرف على الأقل',
    'passwords_do_not_match' => 'كلمات المرور غير متطابقة',
    'invalid_port' => 'يجب أن يكون المنفذ بين 1 و 65535',

    // Progress
    'step_of' => 'الخطوة :current من :total',

    // Timezones
    'timezone_utc' => 'UTC',
    'timezone_america_new_york' => 'أمريكا/نيويورك',
    'timezone_america_chicago' => 'أمريكا/شيكاغو',
    'timezone_america_denver' => 'أمريكا/دنفر',
    'timezone_america_los_angeles' => 'أمريكا/لوس أنجلوس',
    'timezone_europe_london' => 'أوروبا/لندن',
    'timezone_europe_paris' => 'أوروبا/باريس',
    'timezone_europe_berlin' => 'أوروبا/برلين',
    'timezone_asia_tokyo' => 'آسيا/طوكيو',
    'timezone_asia_shanghai' => 'آسيا/شنغهاي',
    'timezone_asia_dubai' => 'آسيا/دبي',
    'timezone_asia_riyadh' => 'آسيا/الرياض',

    // Languages
    'language_english' => 'English',
    'language_arabic' => 'العربية',

    // Completion Page
    'completion_title' => 'تم إكمال التثبيت',
    'completion_subtitle' => 'تم تثبيت وتكوين النظام بنجاح',
    'installation_completed' => 'تم إكمال التثبيت بنجاح!',
    'installation_success_message' => 'تهانينا! تم تثبيت وتكوين نظام إدارة التراخيص بنجاح.',
    'admin_account_created' => 'تم إنشاء حساب المدير',
    'account_status' => 'الحالة',
    'email_verified' => 'البريد الإلكتروني مفعل',
    'system_information' => 'معلومات النظام',
    'database_connected' => 'قاعدة البيانات',
    'important_notice' => 'إشعار أمني مهم',
    'delete_install_folder_warning' => 'لأسباب أمنية، يرجى حذف مجلد التثبيت بعد إكمال عملية التثبيت.',
    'next_steps' => 'الخطوات التالية',
    'delete_install_folder' => 'حذف مجلد التثبيت',
    'delete_install_folder_description' => 'قم بإزالة مجلد التثبيت لمنع الوصول غير المصرح به إلى معالج التثبيت.',
    'configure_system' => 'تكوين النظام',
    'configure_system_description' => 'الوصول إلى لوحة الإدارة لتكوين إعدادات النظام والتفضيلات.',
    'secure_system' => 'تأمين النظام',
    'secure_system_description' => 'مراجعة إعدادات الأمان وتكوين تدابير أمنية إضافية.',
    'go_to_admin_panel' => 'الذهاب إلى لوحة الإدارة',
    'go_to_frontend' => 'الذهاب إلى الواجهة الأمامية',
    'completion_note' => 'يمكنك دائماً الوصول إلى لوحة الإدارة من الواجهة الأمامية بتسجيل الدخول بحساب المدير.',
    'database_created' => 'تم انشاء قاعدة البيانات',
    'system_configured' => 'تم تكوين النظام',
    // Email Configuration
    'email_configuration' => 'إعدادات البريد الإلكتروني',
    'email_configuration_subtitle' => 'تكوين إعدادات البريد الإلكتروني للإشعارات ورسائل النظام (اختياري)',
    'enable_email_notifications' => 'تفعيل إشعارات البريد الإلكتروني',
    'enable_email_hint' => 'حدد هذا لتكوين إعدادات البريد الإلكتروني. يمكنك تخطي هذا وتكوينه لاحقاً من لوحة الإدارة.',
    'mail_mailer' => 'برنامج البريد',
    'mail_host' => 'خادم SMTP',
    'mail_port' => 'منفذ SMTP',
    'mail_encryption' => 'التشفير',
    'mail_username' => 'اسم مستخدم SMTP',
    'mail_password' => 'كلمة مرور SMTP',
    'mail_password_placeholder' => 'أدخل كلمة مرور البريد الإلكتروني أو كلمة مرور التطبيق',
    'mail_password_hint' => 'لـ Gmail، استخدم كلمة مرور التطبيق بدلاً من كلمة المرور العادية',
    'mail_from_address' => 'عنوان البريد الإلكتروني المرسل',
    'mail_from_name' => 'اسم المرسل',
    'mail_from_name_placeholder' => 'اسم شركتك',

    'previous' => 'السابق',
];
